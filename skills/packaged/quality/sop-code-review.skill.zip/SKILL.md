---
name: sop-code-review
description: Standardize code review execution with repeatable steps, evidence requirements, and confidence ceilings.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Provide a concise, repeatable SOP for conducting code reviews that meet evidential and structural standards across repositories.

### Library Component References

Before implementing quality checks, check these library components:
- `pattern-matcher` - Generic pattern detection with regex (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `violation-factory` - SARIF-compatible violation creation (`library.components.analysis.violation_factory`)
- `quality-validator` - Evidence-based quality validation (`library.components.validation.quality_validator`)
- `ast-visitor-base` - Python AST traversal for code analysis (`library.components.analysis.ast_visitor`)
- `metric-collector` - Prometheus-compatible metrics (`library.components.analysis.metric_collector`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE `from library.components.analysis import {Class}` |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** teams requesting a reference SOP, onboarding reviewers, or normalizing review quality across projects.
- **Negative:** deep-dive audits (use code-review-assistant) or runtime debugging (use functionality-audit).

### Guardrails
- **Confidence ceiling:** Include `Confidence: X.XX (ceiling: TYPE Y.YY)` with ceilings {inference/report 0.70, research 0.85, observation/definition 0.95}.
- **Evidence requirements:** Every finding must include file:line, severity, and a reference (standard, guide, or metric).
- **Structure-first:** Ensure examples/tests show correct review phrasing, severity, and confidence statements.
- **Adversarial validation:** Spot-check for false positives and confirm blockers truly block functionality or safety.

### Execution Phases
1. **Preparation**
   - Understand change intent, risk areas, and exclusions.
   - Set severity definitions and merge criteria (blocker/major/minor/nit).
2. **Review Passes**
   - Security and correctness first; then tests and completeness; finish with style/documentation.
   - Capture findings with evidence type and suggested fix.
3. **Summary & Decision**
   - Group findings, flag blockers, and propose next steps.
   - Provide approval recommendation and confidence with ceiling.
4. **Follow-through**
   - Track remediation owners and due dates; rerun spot checks after fixes.

### Output Format
- Scope, exclusions, and severity definitions.
- Findings list with file:line, severity, evidence, and fix guidance.
- Approval recommendation and confidence statement.

### Validation Checklist
- [ ] Scope and severity model documented.
- [ ] Findings include file:line, evidence, and references.
- [ ] Blockers vs. advisory items separated.
- [ ] Confidence ceiling provided; English-only output.

Confidence: 0.70 (ceiling: inference 0.70) - SOP rewritten to reflect Prompt Architect confidence discipline and Skill Forge structure-first review steps.
