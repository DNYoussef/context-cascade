---
name: verification-quality
description: Verify outputs and claims for accuracy, grounding, and policy compliance with explicit evidence and confidence ceilings.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Assess whether delivered outputs are correct, well-grounded, and policy-compliant by tracing evidence, checking constraints, and calibrating confidence.

### Library Component References

Before implementing quality checks, check these library components:
- `pattern-matcher` - Generic pattern detection with regex (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `violation-factory` - SARIF-compatible violation creation (`library.components.analysis.violation_factory`)
- `quality-validator` - Evidence-based quality validation (`library.components.validation.quality_validator`)
- `ast-visitor-base` - Python AST traversal for code analysis (`library.components.analysis.ast_visitor`)
- `metric-collector` - Prometheus-compatible metrics (`library.components.analysis.metric_collector`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE `from library.components.analysis import {Class}` |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** validating generated content, checking analysis against sources, or confirming policy compliance before delivery.
- **Negative:** code execution debugging (use functionality-audit) or style-only work (use style-audit).

### Guardrails
- **Confidence ceiling:** Always emit `Confidence: X.XX (ceiling: TYPE Y.YY)` with ceilings {inference/report 0.70, research 0.85, observation/definition 0.95}.
- **Evidence mapping:** Link each claim to source evidence with citations or file:line references; flag ungrounded assertions.
- **Constraint coverage:** Verify hard/soft/inferred constraints separately; note unresolved inferences.
- **Structure-first:** Maintain examples/tests demonstrating grounding checks and policy validation.

### Execution Phases
1. **Scope & Constraints**
   - Extract requirements and constraints from the request; categorize as hard, soft, inferred.
   - Identify allowed sources and policies.
2. **Evidence Collection**
   - Gather direct evidence (files, logs, references) and map to claims.
   - Note gaps or conflicts in evidence.
3. **Assessment**
   - For each claim, rate correctness, grounding strength, and policy alignment.
   - Distinguish observation vs. inference; cap confidence accordingly.
4. **Reporting & Remediation**
   - Summarize compliant items, violations, and uncertainties with recommended actions.
   - Provide confidence with explicit ceiling and English-only output.

### Output Format
- Constraint breakdown (hard/soft/inferred) and scope.
- Claim-by-claim verification table with evidence and confidence.
- Violations or gaps with remediation steps.
- Confidence statement using ceiling syntax.

### Validation Checklist
- [ ] Constraints extracted and categorized; policies identified.
- [ ] Evidence linked to each claim; gaps flagged.
- [ ] Confidence capped by evidence type; ceilings stated.
- [ ] Remediation steps proposed for violations.
- [ ] Output in English with explicit confidence ceiling.

Confidence: 0.72 (ceiling: inference 0.70) - SOP rewritten leveraging Prompt Architect confidence and constraint extraction plus Skill Forge structure-first verification.
