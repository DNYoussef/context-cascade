---
name: ui-ux-excellence
description: Drive UI/UX audits and improvements with structured heuristics, user journeys, and validation gates.
---


### L1 Improvement
- Recast the UX skill in Prompt Architect style with clear triggers, heuristics, and confidence ceilings.
- Added structure-first guardrails and validation steps aligned to Skill Forge.
- Clarified outputs (audit + prioritized fixes) with memory tagging.



---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Evaluate and improve product UI/UX using heuristic reviews, user flows, accessibility checks, and prioritized fix plans.

### Library Component References

Before implementing, check these library components:
- `markdown-metadata` - Frontmatter and metadata parsing (`library.components.parsing.markdown_metadata`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `yaml-safe-write` - Atomic YAML file writes (`library.io.yaml_safe_write`)
- `verix-parser` - VERIX epistemic parser (`library.components.cognitive.verix_parser`)
- `skill-validator` - Skill definition validation (`library.components.validation.skill_validator`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** UX/UI audit, usability review, accessibility check, design critique, or journey optimization.
- **Negative:** branding-only requests (route to design specialists) or backend-only tasks.

### Guardrails
- Maintain structure-first docs (SKILL, README, examples/tests/references).
- Apply explicit heuristics: clarity, consistency, affordance, feedback, accessibility, performance.
- Confidence ceilings required; cite evidence (screens, flows, metrics).
- Memory tagging for audits and recommendations.

### Execution Phases
1. **Intent & Context** – Identify product area, target users, platforms, and success metrics.
2. **Heuristic Review** – Assess clarity, consistency, affordance, feedback, and accessibility; capture screenshots/notes.
3. **Journey Analysis** – Map critical flows; note friction points, latency, and error states.
4. **Prioritized Plan** – Rank issues by severity/impact/effort; propose design/UX changes.
5. **Validation** – Prototype or simulate fixes when possible; ensure accessibility (WCAG) and responsiveness.
6. **Delivery** – Provide findings, recommended changes, and confidence ceiling with memory keys.

### Output Format
- Audit summary, user flows assessed, key issues with evidence, and prioritized fixes.
- Accessibility/performance notes and suggested metrics to track.
- Confidence: X.XX (ceiling: TYPE Y.YY); memory namespace recorded.

### Validation Checklist
- [ ] Scope and personas defined; platforms noted.
- [ ] Heuristics applied with evidence; accessibility checked.
- [ ] Prioritized backlog includes impact/effort/owner.
- [ ] Confidence ceiling declared; memory tagged.

### Integration
- **Memory MCP:** `skills/tooling/ui-ux-excellence/{project}/{timestamp}` for audits and artifacts.
- **Hooks:** follow Skill Forge latency bounds; integrate with screenshot tooling when available.

Confidence: 0.70 (ceiling: inference 0.70) – SOP aligned to Prompt Architect clarity and Skill Forge guardrails.
