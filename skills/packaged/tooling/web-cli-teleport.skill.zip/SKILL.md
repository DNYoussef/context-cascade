---
name: web-cli-teleport
description: Teleport between web and CLI contexts with synchronized actions, credentials, and safety rails.
---


### L1 Improvement
- Reframed the teleport skill with Prompt Architect clarity and Skill Forge guardrails.
- Added explicit routing, safety constraints, and memory tagging.
- Clarified output expectations and confidence ceilings.



---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Bridge web and CLI tasks safely—execute commands, capture outputs, and synchronize state while respecting permissions and auditability.

### Library Component References

Before implementing, check these library components:
- `markdown-metadata` - Frontmatter and metadata parsing (`library.components.parsing.markdown_metadata`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `yaml-safe-write` - Atomic YAML file writes (`library.io.yaml_safe_write`)
- `verix-parser` - VERIX epistemic parser (`library.components.cognitive.verix_parser`)
- `skill-validator` - Skill definition validation (`library.components.validation.skill_validator`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** need to mirror actions between browser and terminal, fetch artifacts, or reproduce web steps in CLI.
- **Negative:** high-risk admin operations without approvals; route to platform specialists.

### Guardrails
- Structure-first docs maintained (SKILL, README, process diagram).
- Respect credential boundaries; never store secrets in outputs.
- Enforce safety prompts for destructive commands; prefer dry-runs first.
- Confidence ceilings on inferred states; cite observed outputs.
- Memory tagging for session actions.

### Execution Phases
1. **Intent & Scope** – Define goal, environments, and constraints (read-only vs write, network limits).
2. **Context Sync** – Capture current web state (URL, form data) and CLI state (cwd, env); note assumptions.
3. **Plan** – Map steps across web/CLI; identify risky actions and mitigations.
4. **Execute** – Perform actions with logging; use dry-run or safe flags; verify after each step.
5. **Validate** – Confirm state convergence (files, configs, outputs); capture evidence.
6. **Deliver** – Summarize actions, artifacts, and confidence line; store session memory.

### Output Format
- Goal, environments, actions taken (web + CLI) with evidence and timestamps.
- Risks handled, remaining gaps, and next steps.
- Memory namespace and confidence: X.XX (ceiling: TYPE Y.YY).

### Validation Checklist
- [ ] Permissions/credentials confirmed; secrets not logged.
- [ ] Risky commands gated or dry-run first.
- [ ] Web and CLI states reconciled; evidence captured.
- [ ] Memory tagged; confidence ceiling declared.

### Integration
- **Process:** see `web-cli-teleport-process.dot` for flow.
- **Memory MCP:** `skills/tooling/web-cli-teleport/{project}/{timestamp}` for session logs.
- **Hooks:** follow Skill Forge latency bounds; abort on safety violations.

Confidence: 0.70 (ceiling: inference 0.70) – SOP aligned to Prompt Architect clarity and Skill Forge safeguards.
