---
name: gemini-megacontext
description: Gemini mega-context patterns for very large prompts and retrieval planning.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose
Orchestrate Gemini sessions that need extended context windows with structured retrieval and summarization.

### Library Component References

Before implementing, check these library components:
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `memory-mcp-client-v2` - Thread-safe Memory MCP client (`library.components.memory.memory_mcp_client`)
- `redis-cache` - Redis caching layer (`library.components.caching.redis_cache`)
- `redis-pubsub` - Redis pub/sub manager (`library.components.messaging.redis_pubsub`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Trigger Conditions
- **Use this skill when:** Need to load extensive documents or multi-session history into Gemini responsibly.
- **Reroute when:** If context fits standard window, use gemini-search or base prompts.

## Guardrails (Inherited from Skill-Forge + Prompt-Architect)
- Structure-first: every platform skill keeps `SKILL.md`, `examples/`, and `tests/` populated; create `resources/` and `references/` as needed. Log any missing artifact and fill a placeholder before proceeding.
- Confidence ceilings are mandatory in outputs: inference/report 0.70, research 0.85, observation/definition 0.95. State as `Confidence: X.XX (ceiling: TYPE Y.YY)`.
- English-only user-facing text; keep VCL markers internal. Do not leak internal notation.
- Adversarial validation is required before sign-off: boundary, failure, and COV checks with notes.
- MCP tagging for runs: `WHO=gemini-megacontext-{session}`, `WHY=skill-execution`, namespace `skills/platforms/gemini-megacontext/{project}`.

## Execution Framework
1. **Intent & Constraints** — clarify task goal, inputs, success criteria, and risk limits; extract hard/soft/inferred constraints explicitly.
2. **Plan & Docs** — outline steps, needed examples/tests, and data contracts; confirm platform-specific policies.
3. **Build & Optimize** — apply platform playbook below; keep iterative checkpoints and diffs.
4. **Validate** — run adversarial tests, measure KPIs, and record evidence with ceilings.
5. **Deliver & Hand off** — summarize decisions, artifacts, and next actions; capture learnings for reuse.

## Platform Playbook
- **Workflow patterns:**
  - Chunk and summarize sources with traceable citations
  - Stage retrieval + compression before final response
  - Manage context budgets with sliding windows and memory tags
- **Anti-patterns to avoid:** Dumping raw corpora without indexing, Losing citation trails during compression, Exceeding context budget without safeguards
- **Example executions:**
  - Summarize 500-page report with iterative compression
  - Conduct research sessions using staged retrieval and notes

## Documentation & Artifacts
- `SKILL.md` (this file) is canonical; keep quick-reference notes in `README.md` if present.
- `examples/` should hold runnable or narrative examples; `tests/` should include validation steps or checklists.
- `resources/` stores helper scripts/templates; `references/` stores background links or research.
- Update `metadata.json` version if behavior meaningfully changes.

## Verification Checklist
- [ ] Trigger matched and reroute considered
- [ ] Examples/tests present or stubbed with TODOs
- [ ] Constraints captured and confidence ceiling stated
- [ ] Validation evidence captured (boundary, failure, COV)
- [ ] MCP tags applied for this run

Confidence: 0.70 (ceiling: inference 0.70) - Standardized platform skill rewrite aligned with skill-forge + prompt-architect guardrails.
