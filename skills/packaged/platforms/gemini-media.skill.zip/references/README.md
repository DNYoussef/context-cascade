# gemini-media references

Placeholder created during platform skill normalization. Replace with concrete references materials aligned to the SOP.
