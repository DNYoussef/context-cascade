# gemini-extensions examples

Placeholder created during platform skill normalization. Replace with concrete examples materials aligned to the SOP.
