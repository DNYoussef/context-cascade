---
name: infrastructure
description: Design and deliver core infrastructure with resilient operations
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Create secure, scalable infrastructure foundations covering network, compute, storage, identity, and observability with validated IaC.

### Library Component References

Before implementing, check these library components:
- `circuit-breaker` - Fail-fast pattern with backoff (`library.resilience.circuit_breaker`)
- `health-monitor` - Periodic health polling (`library.monitoring.health_monitor`)
- `tagging-protocol` - WHO/WHEN/PROJECT/WHY tagging (`library.components.observability.tagging_protocol`)
- `audit-logging` - Structured audit logging (`library.components.observability.audit_logging`)
- `opentelemetry-lite` - OpenTelemetry wrapper (`library.components.observability.opentelemetry_lite`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** New environment or platform build; Infrastructure modernization or consolidation; Baseline security/operations review
- **Negative:** Container packaging only (route to docker-containerization); Kubernetes-specific asks (route to kubernetes-specialist); Performance triage (route to performance-analysis)

### Guardrails
- Structure-first: keep SKILL.md aligned with examples/, tests/, and any resources/references so downstream agents always have scaffolding.
- Adversarial validation is mandatory: cover boundary cases, failure paths, and rollback drills before declaring the SOP complete.
- Prompt hygiene: separate hard vs. soft vs. inferred constraints and confirm inferred constraints before acting.
- Explicit confidence ceilings: format as 'Confidence: X.XX (ceiling: TYPE Y.YY)' and never exceed the ceiling for the claim type.
- MCP traceability: tag sessions WHO=operations-{name}-{session_id}, WHY=skill-execution, and capture evidence links in outputs.
- Avoid anti-patterns: undocumented changes, missing rollback paths, skipped tests, or unbounded automation without approvals.

### Required Artifacts
- SKILL.md (this SOP)
- readme.md
- examples/ for architectures
- tests/ for infrastructure checks
- resources/ scripts/templates

### Execution Phases
1. **Capture requirements**
   - Document workloads, data needs, compliance, and SLOs
   - Separate hard vs. soft constraints and confirm owners
   - Assess current state and gaps

2. **Design architecture**
   - Plan network, identity, compute, storage, and security controls
   - Select delivery patterns (IaC, pipelines, artifact strategy)
   - Define observability, backup, and DR baselines

3. **Implement and stage**
   - Codify infrastructure via IaC with peer review
   - Deploy to non-prod with smoke tests and drift detection
   - Harden access, secrets, and audit trails

4. **Validate and hand off**
   - Run security/performance/availability checks
   - Record capacity plans and cost expectations
   - Document runbooks, escalation, and change control

### Output Format
- Reference architecture and decision log
- IaC plan with modules, pipelines, and review points
- Capacity/performance profile with assumptions
- Operational runbook with monitoring and backups
- Risk register with mitigations and owners

### Validation Checklist
- Security and compliance controls mapped and tested
- Performance and capacity checks executed or planned
- Backup/DR and observability paths in place
- Change control and ownership documented
- Confidence ceiling stated for environment readiness

Confidence: 0.70 (ceiling: inference 0.70) - Infrastructure SOP mirrors skill-forge structure with IaC validation
