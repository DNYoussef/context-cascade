---
name: reverse-engineer-debug
description: Rapid triage and debug of binaries or artifacts with static + light dynamic analysis for safe insights.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose
Provide quick-turn reverse engineering triage (strings, headers, symbols, lightweight emulation) to answer "what is this binary doing?" without deep instrumentation. Aligns with **skill-forge** structure-first and **prompt-architect** constraint/evidence rules.

### Library Component References

Before implementing, check these library components:
- `jwt-auth-middleware` - JWT auth middleware (`library.auth.jwt_middleware`)
- `fastapi-jwt-auth` - FastAPI JWT auth (`library.auth.fastapi_jwt`)
- `audit-logging` - Structured audit logging (`library.components.observability.audit_logging`)
- `spec-validation` - JSON Schema validation (`library.components.validation.spec_validation`)
- `pattern-matcher` - Pattern detection for threats (`library.components.analysis.pattern_matcher`)
- `tenant-isolation` - Multi-tenant RLS isolation (`library.components.multi_entity.isolation`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Use When / Redirect When
- **Use when:** you need rapid classification, capability hints, or safe behavior summaries.
- **Redirect when:** deep dynamic work (`reverse-engineering-deep`), firmware (`reverse-engineering-firmware`), or quick IOC-only triage (`reverse-engineering-quick`).

## Guardrails
- Analyze only in isolated sandboxes with no production connectivity.
- Never execute unknown binaries outside instrumentation; prefer emulation/snapshots.
- Strip/neutralize secrets; avoid uploading malware to third-party services.
- Confidence ceilings: inference/report ≤0.70, research 0.85, observation/definition 0.95.

## Prompt Architecture Overlay
1. HARD/SOFT/INFERRED constraints (platform, architecture, goals, allowed tooling, time budget).
2. Two passes: structure (coverage, safety) then epistemic (evidence, ceilings).
3. English-only output with explicit confidence line.

## SOP (Triage Loop)
1. **Scope & Safety**
   - Confirm authorization, sample hashes, and isolation settings.
   - Select toolchain (strings, objdump, yara, ghidra-lite, qemu/strace in safe mode).
2. **Static Recon**
   - Identify format/arch, imports/exports, packers/obfuscation, and suspicious strings/URLs.
   - Run YARA/signature checks and entropy/section analysis.
3. **Light Dynamic**
   - Use emulation or sandboxed execution with blocked network; capture syscalls, file/registry/process activity.
   - Stop if behavior exceeds scope (spawn self-modifying code, persistence attempts).
4. **Assessment**
   - Summarize capabilities, indicators (IOCs), and risk level.
   - Recommend next steps (deep analysis, memory dump, firmware path).
5. **Validation & Delivery**
   - Cross-check static vs. dynamic observations; ensure evidence per claim.
   - Archive artifacts under `skills/security/reverse-engineer-debug/{project}/{timestamp}` with MCP tags (`WHO=reverse-engineer-debug-{session}`, `WHY=skill-execution`).

## Deliverables
- Capability summary, IOC list (hashes/domains/paths), and risk assessment.
- Evidence bundle (tool outputs, hashes, logs) with timestamps.
- Recommended follow-up (e.g., deep analysis, detonation plan).

## Quality Gates
- Structure-first documentation; missing resources/examples/tests noted for follow-up.
- Evidence attached to every claim; confidence ceiling stated.
- Safety controls verified (network blocked or allowlisted, snapshots taken).
- Triaged within agreed time budget; escalation path documented.

## Anti-Patterns
- Running unknown binaries with unrestricted network access.
- Publishing results without hashes or evidence.
- Overstating confidence beyond ceiling.
- Skipping routing to deeper skills when needed.

## Output Format
- Scope + constraints table (HARD/SOFT/INFERRED).
- Findings (static + light dynamic) with evidence and IOCs.
- Next-step recommendations and safety notes.
- Confidence line: `Confidence: X.XX (ceiling: TYPE Y.YY) - reason`.

Confidence: 0.71 (ceiling: inference 0.70) - Triage SOP rebuilt with skill-forge structure and prompt-architect constraint discipline.
