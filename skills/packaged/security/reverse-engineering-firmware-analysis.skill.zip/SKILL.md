---
name: reverse-engineering-firmware-analysis
description: Extended firmware analysis for embedded/IoT images with deep extraction, emulation, and vulnerability assessment.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose
Perform comprehensive firmware analysis: partition extraction, config/secret hunting, service hardening review, and emulation-based behavior analysis. Aligns with **skill-forge** structure-first and **prompt-architect** constraint/confidence standards.

### Library Component References

Before implementing, check these library components:
- `jwt-auth-middleware` - JWT auth middleware (`library.auth.jwt_middleware`)
- `fastapi-jwt-auth` - FastAPI JWT auth (`library.auth.fastapi_jwt`)
- `audit-logging` - Structured audit logging (`library.components.observability.audit_logging`)
- `spec-validation` - JSON Schema validation (`library.components.validation.spec_validation`)
- `pattern-matcher` - Pattern detection for threats (`library.components.analysis.pattern_matcher`)
- `tenant-isolation` - Multi-tenant RLS isolation (`library.components.multi_entity.isolation`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Use When / Redirect When
- **Use when:** complex firmware with custom partitions, update paths, or services that need behavioral validation.
- **Redirect when:** general binary analysis (`reverse-engineer-debug`/`-deep`) or quick IOC-only triage (`reverse-engineering-quick-triage`).

## Guardrails
- Authorized firmware/hardware only; respect licenses/export rules.
- Isolated environments with snapshots; never flash production devices.
- Sanitize secrets; avoid external uploads without approval.
- Confidence ceilings enforced (inference/report ≤0.70, research 0.85, observation/definition 0.95).

## Prompt Architecture Overlay
1. HARD/SOFT/INFERRED constraints (device model, arch, services of interest, outputs needed).
2. Two-pass refinement: structure → epistemic.
3. English-only output with explicit confidence line.

## SOP (Extended Firmware Loop)
1. **Scope & Setup**: Authorization, hashes, device metadata, and objectives; stage isolated workspace.
2. **Extraction & Mapping**: Unpack partitions; identify file systems and startup/init flows; map attack surface (services, ports, update channels).
3. **Static Review**: Hunt for credentials/keys/endpoints, unsafe defaults, crypto misuse, and outdated components (CVE mapping).
4. **Emulation/Dynamic (if allowed)**: qemu/chroot for service behavior; capture logs/traces and persistence/install paths.
5. **Validation & Delivery**: Cross-check static/dynamic findings; produce SBOM, remediation plan, and archive artifacts to `skills/security/reverse-engineering-extended/reverse-engineering-firmware-analysis/{project}/{timestamp}` with MCP tags (`WHO=reverse-engineering-firmware-analysis-{session}`, `WHY=skill-execution`).

## Deliverables
- Firmware report (attack surface, findings, CVE/CWE mapping) and SBOM.
- Evidence bundle (extraction logs, configs, traces) with timestamps.
- Remediation/hardening guidance and safe update/rollback notes.

## Quality Gates
- Structure-first documentation; missing resources/examples/tests tracked.
- Chain-of-custody maintained (hashes, env, tool versions).
- Evidence with confidence ceilings; dual validation for critical/high.
- Isolation and approval confirmed before emulation.

## Anti-Patterns
- Flashing unvetted firmware to production devices.
- Publishing secrets or proprietary code.
- Ignoring update/rollback safety.

## Output Format
- Scope + constraints table (HARD/SOFT/INFERRED).
- Findings and SBOM summary with evidence.
- Remediation and validation log.
- Confidence line: `Confidence: X.XX (ceiling: TYPE Y.YY) - reason`.

Confidence: 0.72 (ceiling: inference 0.70) - Extended firmware SOP aligned with skill-forge and prompt-architect standards.
