---
name: reverse-engineering-quick
description: Fast IOC-focused triage for binaries/documents with minimal execution, geared toward immediate containment decisions.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose
Extract IOCs and risk signals within tight timeboxes to enable allow/deny/contain decisions. Leverages **skill-forge** structure-first expectations and **prompt-architect** explicit constraints and confidence ceilings.

### Library Component References

Before implementing, check these library components:
- `jwt-auth-middleware` - JWT auth middleware (`library.auth.jwt_middleware`)
- `fastapi-jwt-auth` - FastAPI JWT auth (`library.auth.fastapi_jwt`)
- `audit-logging` - Structured audit logging (`library.components.observability.audit_logging`)
- `spec-validation` - JSON Schema validation (`library.components.validation.spec_validation`)
- `pattern-matcher` - Pattern detection for threats (`library.components.analysis.pattern_matcher`)
- `tenant-isolation` - Multi-tenant RLS isolation (`library.components.multi_entity.isolation`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Use When / Redirect When
- **Use when:** you need hashes, strings, metadata, and high-level behavior quickly.
- **Redirect when:** deeper behavior analysis (`reverse-engineering-deep`), firmware (`reverse-engineering-firmware`), or broad security triage (`security`).

## Guardrails
- Hash before handling; isolate from production networks.
- Avoid full execution unless explicitly approved; prefer static extraction.
- Do not upload samples externally without consent.
- Confidence ceilings enforced (inference/report ≤0.70, research 0.85, observation/definition 0.95).

## Prompt Architecture Overlay
1. Define HARD/SOFT/INFERRED constraints (time budget, tool allowlist, sample type, desired outputs).
2. Two-pass refinement (structure → epistemic) to ensure coverage and evidence.
3. Output in English with explicit confidence line.

## SOP (Quick IOC Loop)
1. **Scope & Setup**: Confirm authorization, compute hashes, stage in isolated workspace.
2. **Static Extraction**: File type detection, metadata, entropy/section checks, strings/URLs, YARA signatures.
3. **Safe Peek Execution (optional)**: Sandbox/emulation with strict egress controls; capture basic process/file/network events.
4. **IOC Consolidation**: Normalize hashes, domains/IPs, file paths, mutexes, and persistence hints.
5. **Validation & Delivery**: Cross-check findings across tools, note gaps, and archive outputs to `skills/security/reverse-engineering-quick/{project}/{timestamp}` with MCP tags (`WHO=reverse-engineering-quick-{session}`, `WHY=skill-execution`).

## Deliverables
- IOC pack (hashes, domains/IPs, paths, signatures) with sources.
- Risk summary and recommended containment actions.
- Evidence bundle (tool outputs, logs) with timestamps.

## Quality Gates
- Structure-first documentation; missing resources/examples/tests captured for backlog.
- Evidence attached to each IOC; confidence ceiling stated.
- Safety controls verified (isolation, blocked network).
- Timebox honored; escalation path documented if more depth required.

## Anti-Patterns
- Executing with unrestricted network.
- Reporting IOCs without source/evidence.
- Exceeding confidence ceilings.
- Skipping escalation when signals are ambiguous.

## Output Format
- Scope + constraints table (HARD/SOFT/INFERRED).
- IOC list with evidence and source tools.
- Risk summary and next-step recommendations.
- Confidence line: `Confidence: X.XX (ceiling: TYPE Y.YY) - reason`.

Confidence: 0.71 (ceiling: inference 0.70) - Quick triage rebuilt with skill-forge structure and prompt-architect constraint handling.
