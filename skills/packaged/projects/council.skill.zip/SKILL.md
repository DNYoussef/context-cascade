---
name: council
description: Open and manage the Corporate Advisor Council project - a 12-role AI advisory board with Byzantine fault-tolerant consensus voting across Claude, Gemini, and OpenAI via OpenRouter. Use when starting, developing, or debugging the council backend/frontend.
---



---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose

Launch and manage the Corporate Advisor Council - David Youssef's personal AI advisory board providing consensus-driven recommendations using Byzantine fault-tolerant voting across multiple LLM providers via OpenRouter.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)
- `yaml-safe-write` - Atomic YAML file writes (`library.io.yaml_safe_write`)
- `spec-validation` - JSON Schema validation (`library.components.validation.spec_validation`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Trigger Conditions

- **Use this skill when:** User mentions "council", "advisory board", "corporate council", wants to start/stop council services, or work on the council codebase
- **Keywords:** council, corporate advisor, advisory board, byzantine consensus, multi-model debate, deliberation, 12 advisors
- **Reroute when:** For general multi-model routing without council project, use `multi-model` skill. For full ecosystem startup, use `/startup`.

## Guardrails

- Always verify `.env` exists with valid `COUNCIL_OPENROUTER_API_KEY` before starting services
- Never expose API keys in logs or output
- Check port availability before starting services (8002 for backend, 5173 for frontend)
- Run quality gates (connascence analyzer) before commits
- MCP tagging: `WHO=council-skill`, `WHY=project-management`, namespace `skills/projects/council`

## Project Structure

```
D:\Projects\corporate-council\
  src/council/
    advisors/           # Claude, Gemini, OpenAI implementations
      base.py           # AdvisorBase ABC
      fallback.py       # FallbackManager with circuit breaker
      claude/           # Claude advisor via OpenRouter
      gemini/           # Gemini advisor via OpenRouter
      openai/           # OpenAI advisor via OpenRouter
    api/                # FastAPI REST + WebSocket
      main.py           # Application entry (port 8002)
      routers/          # Endpoint handlers
        debate.py       # POST /api/v1/debates
        session.py      # GET /api/v1/sessions/{id}
        costs.py        # Cost tracking endpoints
    orchestration/      # 5-phase deliberation engine
      orchestrator.py   # Main coordinator (DeliberationOrchestrator)
      phases/           # Phase runners (opinions, voting, red_team, synthesis)
    models/             # SQLAlchemy ORM
    schemas/            # Pydantic schemas
    config/             # Settings and advisor configs
      advisors.py       # 12 advisor definitions with OpenRouter models
      settings.py       # Pydantic settings
    engine/             # Database engine
  frontend/             # Vite + React + TailwindCSS (TODO)
  tests/                # Unit and integration tests
```

## Execution Framework

### Phase 1: Environment Verification

**Objective**: Confirm all prerequisites are met before starting services.

**Steps** (execute in order):
1. Navigate to project directory: `cd D:\Projects\corporate-council`
2. Verify `.env` file exists: `Test-Path .env` must return `True`
3. Confirm `COUNCIL_OPENROUTER_API_KEY` is set (not placeholder `sk-or-v1-...`)
4. Verify PostgreSQL is running: `pg_isready -h localhost -p 5432`
5. Confirm database accessible: `psql -h localhost -U sparc_user -d sparc_dashboard -c "\dt"`

**Success Criteria**:
- `.env` file exists with valid OpenRouter API key
- PostgreSQL service responds on port 5432
- Database connection succeeds with correct credentials

**Failure Recovery**:
- Missing `.env`: Copy from `.env.example` and add your API key
- PostgreSQL not running: Start service with `net start postgresql-x64-15`
- Database missing: Create with `createdb -U sparc_user sparc_dashboard`

---

### Phase 2: Start Backend

**Objective**: Launch the FastAPI backend server on port 8002.

**Steps** (execute in order):
```powershell
# Set working directory
cd D:\Projects\corporate-council

# Set PYTHONPATH (CRITICAL - prevents import errors)
$env:PYTHONPATH = "D:\Projects\corporate-council\src"

# Start uvicorn with hot reload
python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload
```

**Success Criteria**:
- Server binds to port 8002 without errors
- Log shows "Application startup complete"
- No import errors or missing module warnings

**Failure Recovery**:
- Port in use: Find and kill process with `netstat -ano | findstr :8002` then `taskkill /F /PID <pid>`
- Import errors: Verify PYTHONPATH is set correctly
- Module not found: Run `pip install -r requirements.txt`

---

### Phase 3: Verify Services

**Objective**: Confirm backend is healthy and accessible.

**Steps**:
```bash
# Check health endpoint
curl http://localhost:8002/health

# Expected response:
# {"status":"healthy","version":"0.4.0","service":"Corporate Advisor Council API"}

# Verify API docs load
curl -s -o /dev/null -w "%{http_code}" http://localhost:8002/docs
# Expected: 200
```

**Success Criteria**:
- Health endpoint returns HTTP 200 with status "healthy"
- API docs endpoint returns HTTP 200
- Version matches expected (0.4.0 or higher)

**Failure Recovery**:
- Connection refused: Verify server is running and port is correct
- 500 error: Check server logs for stack trace
- Timeout: Increase timeout or check for blocking operations

---

### Phase 4: Test Deliberation

**Objective**: Submit a test question and verify full deliberation pipeline.

**Steps**:
```bash
# Submit deliberation request
curl -X POST http://localhost:8002/api/v1/debates \
  -H "Content-Type: application/json" \
  -d '{"question":"Should we expand to Asia?","question_type":"STRATEGIC","urgency":"THIS_WEEK"}'

# Expected: 202 Accepted with session_id

# Poll for result (replace session_id)
curl http://localhost:8002/api/v1/sessions/{session_id}
```

**Success Criteria**:
- Initial request returns 202 Accepted with valid session_id (UUID format)
- Quorum achieved (8/12 advisors responded)
- Byzantine consensus reached (67%+ weighted majority)
- Final result includes recommendation (PROCEED/DECLINE/DEFER/CONDITIONAL)

**Failure Recovery**:
- Timeout (504): Increase `DEFAULT_ADVISOR_TIMEOUT` to 60s
- Partial quorum: Check individual advisor connectivity
- No consensus: Review advisor weights and voting logic

## Quick Commands

```powershell
# Start backend (recommended)
cd D:\Projects\corporate-council
$env:PYTHONPATH = "D:\Projects\corporate-council\src"
python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload

# Or using bash
cd D:/Projects/corporate-council && PYTHONPATH=src python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload

# Run tests
cd D:\Projects\corporate-council
pytest tests/ -v

# Quality check
claude-dev quality analyze D:\Projects\corporate-council\src\council
```

## Service URLs

| Service | URL | Purpose |
|---------|-----|---------|
| Backend API | http://localhost:8002 | REST API |
| API Docs | http://localhost:8002/docs | Swagger/OpenAPI |
| Health Check | http://localhost:8002/health | Service status |
| Debates | http://localhost:8002/api/v1/debates | Create/list debates |
| Sessions | http://localhost:8002/api/v1/sessions | Session status |

## Architecture Overview

- **12 Advisors:** 4 Governance + 3 Revenue + 3 Operations + 2 Technical (voting members)
- **Models via OpenRouter:**
  - `anthropic/claude-3.5-sonnet` - Governance, Operations, Technical
  - `google/gemini-pro-1.5` - Revenue cluster
  - `openai/gpt-4o` - Technical cluster
- **5-Phase Deliberation:**
  1. Independent Opinions - All advisors analyze in parallel (45s timeout)
  2. Cross-Examination - Advisors see others' opinions, may update
  3. Weighted Voting - Question-type-specific vote weighting
  4. Red Team Challenge - Devil's advocate identifies fatal flaws
  5. Synthesis - Chairman creates final recommendation
- **Quorum:** 8/12 advisors must respond for valid consensus
- **Byzantine Consensus:** 67% weighted majority required for PROCEED/DECLINE

## Key Files Reference

| File | Purpose |
|------|---------|
| `src/council/api/main.py` | FastAPI app entry |
| `src/council/api/routers/debate.py` | Debate endpoints + background task |
| `src/council/orchestration/orchestrator.py` | 5-phase engine |
| `src/council/orchestration/phases/opinions.py` | Phase 1-2 opinion gathering |
| `src/council/advisors/base.py` | Advisor ABC |
| `src/council/advisors/claude/advisor.py` | Claude via OpenRouter |
| `src/council/advisors/fallback.py` | Circuit breaker + fallback |
| `src/council/config/advisors.py` | 12 advisor definitions |
| `src/council/config/settings.py` | Pydantic settings |

## Environment Variables

```env
# Required
COUNCIL_OPENROUTER_API_KEY=sk-or-v1-...  # Your OpenRouter API key

# Database (using sparc_dashboard db)
COUNCIL_DATABASE_URL=postgresql+asyncpg://sparc_user:sparc_password@localhost:5432/sparc_dashboard

# Optional
COUNCIL_DEBUG=true
COUNCIL_ENVIRONMENT=development
COUNCIL_DAILY_COST_LIMIT_USD=20.0
COUNCIL_REDIS_URL=redis://localhost:6379/0  # Optional, falls back to in-memory
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `.env` missing | Copy `.env.example` to `.env`, add API key |
| Port 8002 in use | Kill existing process: `taskkill /F /PID <pid>` |
| Import errors | Set `PYTHONPATH=D:\Projects\corporate-council\src` |
| 400 Bad Request | Check model names in `config/advisors.py` match OpenRouter |
| Timeouts | Increase `DEFAULT_ADVISOR_TIMEOUT` in `orchestrator.py` (default: 45s) |
| Database connection fails | Start PostgreSQL, check credentials in `.env` |
| Redis auth error | Normal - falls back to in-memory circuit breaker |

## Recent Fixes (v2.0.0)

- Fixed TypeError in FallbackManager (`consecutive_failures or 0`)
- Fixed SQLAlchemy concurrent session errors (batch commit after gather)
- Fixed session ID mismatch (pass session_id to orchestrator)
- Fixed OpenRouter message format (removed Anthropic cache_control)
- Disabled extended thinking param (OpenRouter incompatible)
- Updated model names to valid OpenRouter IDs
- Increased timeout from 15s to 45s

---

## Input/Output Contracts

```yaml
inputs:
  action:
    type: enum
    required: true
    values: [start, stop, status, debug, test, develop]
    description: Primary action to perform on the council project
  question:
    type: string
    required: false
    description: Question to submit for deliberation (required for 'test' action)
  question_type:
    type: enum
    required: false
    values: [STRATEGIC, OPERATIONAL, FINANCIAL, TECHNICAL, PERSONNEL]
    default: STRATEGIC
    description: Category of question for advisor weighting
  urgency:
    type: enum
    required: false
    values: [IMMEDIATE, THIS_WEEK, THIS_MONTH, THIS_QUARTER]
    default: THIS_WEEK
    description: Urgency level affecting deliberation depth

outputs:
  service_status:
    type: object
    description: Health check response from backend
    schema:
      status: string
      version: string
      service: string
  session_id:
    type: uuid
    description: Unique identifier for deliberation session
  deliberation_result:
    type: object
    description: Final consensus output
    schema:
      recommendation: enum[PROCEED, DECLINE, DEFER, CONDITIONAL]
      confidence: float
      consensus_percentage: float
      dissenting_opinions: array
      red_team_challenges: array
      synthesis: string
  error:
    type: object
    description: Error details if operation fails
    schema:
      code: string
      message: string
      suggestion: string
```

---

## Examples

### Example 1: Start the Council Backend

**Scenario**: Developer wants to start the council API server for local development.

**User Request**: "Start the council backend"

**Execution**:
```powershell
# Step 1: Navigate to project
cd D:\Projects\corporate-council

# Step 2: Verify .env exists
Test-Path .env  # Must return True

# Step 3: Set PYTHONPATH and start server
$env:PYTHONPATH = "D:\Projects\corporate-council\src"
python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload
```

**Success Criteria**:
- Server starts without errors on port 8002
- Health endpoint returns: `{"status":"healthy","version":"0.4.0","service":"Corporate Advisor Council API"}`
- API docs accessible at http://localhost:8002/docs

**Expected Output**:
```
INFO:     Uvicorn running on http://0.0.0.0:8002 (Press CTRL+C to quit)
INFO:     Started reloader process [xxxxx]
INFO:     Started server process [xxxxx]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

---

### Example 2: Submit a Strategic Deliberation

**Scenario**: User wants to get consensus-driven advice on a business decision.

**User Request**: "Ask the council whether we should expand to the European market"

**Execution**:
```bash
# Submit deliberation request
curl -X POST http://localhost:8002/api/v1/debates \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Should we expand our operations to the European market given current economic conditions?",
    "question_type": "STRATEGIC",
    "urgency": "THIS_MONTH"
  }'
```

**Success Criteria**:
- API returns 202 Accepted with session_id
- All 12 advisors respond within 45s timeout
- Quorum achieved (8/12 minimum)
- Byzantine consensus reached (67%+ weighted majority)

**Expected Output**:
```json
{
  "session_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "status": "processing",
  "estimated_completion_seconds": 120
}
```

---

### Example 3: Debug a Failing Deliberation

**Scenario**: Deliberation times out or fails; need to diagnose the issue.

**User Request**: "Debug why the council deliberation is failing"

**Execution**:
```powershell
# Step 1: Check service health
curl http://localhost:8002/health

# Step 2: Check advisor status
curl http://localhost:8002/api/v1/advisors/status

# Step 3: Review logs for errors
Get-Content D:\Projects\corporate-council\logs\council.log -Tail 100

# Step 4: Test individual advisor connectivity
curl -X POST http://localhost:8002/api/v1/advisors/test \
  -H "Content-Type: application/json" \
  -d '{"advisor_id": "ceo_chairman", "timeout_seconds": 30}'

# Step 5: Verify OpenRouter API key
$env:COUNCIL_OPENROUTER_API_KEY | Select-String "sk-or-v1-"
```

**Success Criteria**:
- Root cause identified (timeout, API key, model name, network)
- Specific advisor failure isolated if applicable
- Remediation action determined

**Diagnostic Checklist**:
- [ ] Health endpoint returns 200 OK
- [ ] OpenRouter API key valid and not expired
- [ ] Model names match OpenRouter catalog
- [ ] Network connectivity to api.openrouter.ai
- [ ] Timeout >= 45s configured
- [ ] PostgreSQL database accessible

---

## Common Anti-Patterns

| Anti-Pattern | Problem | Solution |
|--------------|---------|----------|
| **Using Wrong Port** | Starting on port 8000 instead of 8002 | Always use `--port 8002` for council backend |
| **Invalid Model Names** | Using `claude-opus-4-5` instead of valid OpenRouter IDs | Use exact names: `anthropic/claude-3.5-sonnet`, `google/gemini-pro-1.5`, `openai/gpt-4o` |
| **Anthropic Message Format** | Using cache_control array format | Use OpenAI-compatible simple string format |
| **Short Timeouts** | 15s timeout causes advisor failures | Set minimum 45s timeout for OpenRouter latency |
| **Extended Thinking API** | Enabling extended_thinking param | Disable for OpenRouter (incompatible) |
| **Missing PYTHONPATH** | Import errors on startup | Always set `PYTHONPATH=D:\Projects\corporate-council\src` |
| **Placeholder API Key** | Using `sk-or-v1-...placeholder` | Replace with actual OpenRouter API key |
| **Concurrent DB Sessions** | SQLAlchemy session conflicts | Use batch commit after asyncio.gather |

---

## What NOT To Do (Negative Examples)

### DO NOT: Use Wrong Model Names

```python
# WRONG - These model names will cause 400 Bad Request errors
INCORRECT_MODELS = [
    "claude-opus-4-5",           # Does not exist on OpenRouter
    "claude-3-opus",             # Missing provider prefix
    "anthropic/sonnet-4",        # Wrong model name format
    "google/gemini-3-pro",       # Non-existent model version
    "openai/gpt-4-turbo-2024",   # Deprecated model ID
]

# CORRECT - Use exact OpenRouter model IDs
CORRECT_MODELS = [
    "anthropic/claude-3.5-sonnet",  # Governance advisors
    "google/gemini-pro-1.5",        # Revenue advisors
    "openai/gpt-4o",                # Technical advisors
]
```

### DO NOT: Use Anthropic Message Format with OpenRouter

```python
# WRONG - Anthropic-specific format causes parsing errors
messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "text",
                "text": "Analyze this question",
                "cache_control": {"type": "ephemeral"}  # OpenRouter does not support this
            }
        ]
    }
]

# CORRECT - Use OpenAI-compatible simple string format
messages = [
    {
        "role": "user",
        "content": "Analyze this question"  # Simple string, no cache_control
    }
]
```

### DO NOT: Start Server Without PYTHONPATH

```powershell
# WRONG - Causes "ModuleNotFoundError: No module named 'council'"
cd D:\Projects\corporate-council
python -m uvicorn council.api.main:app --port 8002

# CORRECT - Always set PYTHONPATH first
cd D:\Projects\corporate-council
$env:PYTHONPATH = "D:\Projects\corporate-council\src"
python -m uvicorn council.api.main:app --port 8002
```

### DO NOT: Use Short Timeout Values

```python
# WRONG - 15s is too short for OpenRouter's API latency
DEFAULT_ADVISOR_TIMEOUT = 15  # Will cause frequent timeouts

# CORRECT - Use minimum 45s for reliable responses
DEFAULT_ADVISOR_TIMEOUT = 45  # Accounts for network latency + model inference
```

### DO NOT: Commit Database Sessions During Async Gather

```python
# WRONG - Causes "InvalidRequestError: This Session's transaction has been rolled back"
async def process_opinions(self, advisors):
    tasks = [self.get_opinion(advisor) for advisor in advisors]
    results = await asyncio.gather(*tasks)
    for result in results:
        self.session.add(result)
        await self.session.commit()  # Each commit in loop causes conflicts

# CORRECT - Batch commit after all operations complete
async def process_opinions(self, advisors):
    tasks = [self.get_opinion(advisor) for advisor in advisors]
    results = await asyncio.gather(*tasks)
    for result in results:
        self.session.add(result)
    await self.session.commit()  # Single commit after all adds
```

### DO NOT: Enable Extended Thinking for OpenRouter

```python
# WRONG - OpenRouter does not support this Anthropic-specific feature
response = await client.messages.create(
    model="anthropic/claude-3.5-sonnet",
    max_tokens=4096,
    thinking={
        "type": "enabled",
        "budget_tokens": 10000
    },  # OpenRouter will reject this
    messages=messages
)

# CORRECT - Omit thinking parameter entirely
response = await client.messages.create(
    model="anthropic/claude-3.5-sonnet",
    max_tokens=4096,
    # No thinking parameter
    messages=messages
)
```

---

## Cross-Skill Coordination

### Upstream Skills (provide input)
| Skill | When to Use First | What It Provides |
|-------|-------------------|------------------|
| `multi-model` | When routing to multiple LLMs | Model selection logic, API patterns |
| `llm-council` | For consensus architecture design | Byzantine voting algorithms |
| `architect` | When designing new council features | System design, API contracts |

### Downstream Skills (use output)
| Skill | When to Use After | What It Does |
|-------|-------------------|--------------|
| `deployment` | After council is ready for production | Railway/Docker deployment |
| `devops` | For CI/CD pipeline setup | GitHub Actions, automated testing |
| `e2e-test` | After API is stable | End-to-end test suite creation |

### Parallel Skills (work together)
| Skill | When to Use Together | How They Coordinate |
|-------|---------------------|---------------------|
| `debug` | When council has runtime errors | Systematic debugging workflow |
| `fix-bug` | When council has identified bugs | Bug fixing with verification |
| `code-review-assistant` | Before merging council changes | Multi-agent code review |

---

## MCP Requirements

### Required MCPs
| MCP | Purpose | Justification |
|-----|---------|---------------|
| memory-mcp | Store deliberation patterns and outcomes | Cross-session learning from council decisions |
| sequential-thinking | Complex reasoning for debugging | Multi-step diagnostic reasoning |

### Optional MCPs
| MCP | Purpose | When Needed |
|-----|---------|-------------|
| playwright | E2E testing of frontend | When developing council UI |
| flow-nexus | ML pipeline integration | When adding ML-based advisor selection |

### MCP Tagging Protocol
```yaml
WHO: council-skill:{session_id}
WHEN: {ISO8601_timestamp}
PROJECT: corporate-council
WHY: project-management|debugging|deliberation|deployment
```

---

## Recursive Improvement

### Self-Improvement Integration
- **Role**: Project management skill for multi-model consensus system
- **Eval Harness**: Track deliberation success rate, advisor response times, consensus quality
- **Memory Namespace**: `skills/projects/council`

### Metrics to Track
| Metric | Target | Current |
|--------|--------|---------|
| Deliberation success rate | >95% | ~90% |
| Advisor response time (p50) | <30s | ~25s |
| Advisor response time (p95) | <45s | ~40s |
| Quorum achievement rate | >98% | ~95% |
| Consensus confidence | >0.75 | ~0.80 |

### Improvement Loop
1. After each deliberation, log outcome to Memory MCP
2. Weekly aggregate metrics and identify failure patterns
3. Update advisor configs or timeouts based on patterns
4. Re-validate with test deliberations

---

## Completion Verification

### Pre-Flight Checklist
- [ ] `.env` file exists at `D:\Projects\corporate-council\.env`
- [ ] `COUNCIL_OPENROUTER_API_KEY` is set (not placeholder)
- [ ] PostgreSQL service running on localhost:5432
- [ ] Database `sparc_dashboard` accessible with credentials
- [ ] Port 8002 is available (not in use by another process)
- [ ] PYTHONPATH set to project src directory

### Service Verification
- [ ] Backend starts without errors on port 8002
- [ ] Health endpoint returns 200 OK: `GET http://localhost:8002/health`
- [ ] API docs accessible at `http://localhost:8002/docs`
- [ ] All 12 advisors registered in config

### Deliberation Verification
- [ ] Test deliberation returns session_id (202 Accepted)
- [ ] Quorum achieved (8/12 advisors respond)
- [ ] Byzantine consensus reached (67%+ weighted)
- [ ] Session status endpoint returns deliberation result

### Skill Compliance (Skill-Forge v2.0)
- [ ] YAML frontmatter complete with all x- fields
- [ ] Input/Output contracts defined in YAML format
- [ ] 3+ concrete examples with success criteria
- [ ] Anti-patterns table with Problem/Solution columns
- [ ] Cross-skill coordination documented (upstream/downstream/parallel)
- [ ] MCP requirements with justification
- [ ] Recursive improvement metrics defined
- [ ] LEARNED PATTERNS section present

---

Confidence: 0.92 (ceiling: observation 0.95) - Private project skill for Corporate Advisor Council v2.1.0, enhanced with skill-forge v2.0 standards.

---

## LEARNED PATTERNS

### High Confidence [conf:0.90]
- ALWAYS use port 8002 for Corporate Council backend (not 8000) [ground:testing:2026-01-08]
- OpenRouter model names: Use `anthropic/claude-3.5-sonnet`, `google/gemini-pro-1.5`, `openai/gpt-4o` (not opus-4-5, sonnet-4, gemini-3-*) [ground:api-error:2026-01-08]
- OpenRouter message format: Use OpenAI-compatible simple string format, NOT Anthropic's cache_control array format [ground:api-compatibility:2026-01-08]
- Advisor timeout: Minimum 45s for OpenRouter latency (15s too short) [ground:timeout-error:2026-01-08]
- Extended thinking API: Disabled for OpenRouter (incompatible with their format) [ground:api-error:2026-01-08]

### Medium Confidence [conf:0.75]
- 12-advisor Byzantine consensus with 67% weighted majority functions correctly [ground:verification:session-2b03dd60:2026-01-08]
- Database: Uses sparc_dashboard db, requires PostgreSQL running [ground:successful-deployment:2026-01-08]
