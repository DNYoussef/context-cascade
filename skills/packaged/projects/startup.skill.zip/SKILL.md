---
name: startup
description: Initialize the full David Youssef development ecosystem in one command - Corporate Advisor Council, claude-dev-cli, Life OS Dashboard, and Memory MCP. Use for morning startup or full environment launch.
---



---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## Purpose

Launch the complete development ecosystem in a single command. Orchestrates startup of Corporate Advisor Council, claude-dev-cli verification, Life OS Dashboard, and Memory MCP server with proper dependency ordering and health checks.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)
- `yaml-safe-write` - Atomic YAML file writes (`library.io.yaml_safe_write`)
- `spec-validation` - JSON Schema validation (`library.components.validation.spec_validation`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

## Trigger Conditions

- **Use this skill when:** User wants to start their full development environment, morning startup routine, or launch all services
- **Keywords:** startup, start everything, launch all, full environment, morning startup, boot ecosystem, start dev
- **Reroute when:** For council only, use `/council`. For claude-dev-cli only, use `claude-dev` command directly.

## Guardrails

- Verify all `.env` files exist before launching services. STOP if critical env files are missing.
- Check port availability to avoid conflicts. Report blocked ports clearly before proceeding.
- NEVER expose API keys, tokens, or secrets in terminal output or logs.
- Launch services in strict dependency order (database-dependent services LAST).
- Provide clear status output for each service with health check results.
- Use MCP tagging on all operations: `WHO=startup-skill`, `WHY=ecosystem-launch`, namespace `skills/projects/startup`.
- FAIL FAST: If a required service fails to start, halt the startup sequence and report the failure.
- TIMEOUT enforcement: Services must respond to health checks within 30 seconds or be marked as failed.

## Input/Output Contracts

```yaml
inputs:
  flags:
    -All: boolean        # optional - Launch all services including optional ones
    -Outreach: boolean   # optional - Include Slop Detector for outreach pipeline
    -Minimal: boolean    # optional - Launch only Corporate Council backend
    -HealthOnly: boolean # optional - Run health checks without starting services
  environment:
    COUNCIL_OPENROUTER_API_KEY: string  # required - OpenRouter API key in .env
    DATABASE_URL: string                 # required - PostgreSQL connection string
    PYTHONPATH: string                   # auto-set to project src directories

outputs:
  services_started:
    - name: string           # Service name
      port: number           # Port number
      url: string            # Base URL
      status: enum[running, failed, skipped]
      health_check: enum[passed, failed, timeout]

  startup_report:
    total_services: number
    running: number
    failed: number
    skipped: number
    startup_duration_ms: number

  browser_tabs:
    - url: string            # URLs opened in browser
      purpose: string        # Why this tab was opened

  error_log:
    - service: string
      error_type: string
      message: string
      remediation: string
```

## Systems Overview

| System | Path | Ports | Required |
|--------|------|-------|----------|
| Corporate Council Backend | `D:\Projects\corporate-council` | 8002 | Yes |
| Corporate Council Frontend | `D:\Projects\corporate-council\frontend` | 5173 | No (TODO) |
| claude-dev-cli | `D:\Projects\claude-dev-cli` | N/A (CLI) | Yes |
| Life OS Dashboard Backend | `D:\Projects\life-os-dashboard` | 8001 | Optional |
| Life OS Dashboard Frontend | `D:\Projects\life-os-frontend` | 3000 | Optional |
| Memory MCP | `D:\Projects\memory-mcp-triple-system` | 8765 | Optional |
| Slop Detector | `D:\Projects\slop-detector` | 8003 | Optional (Outreach) |

### Outreach Pipeline Components

The recruiter outreach pipeline requires:
- **Slop Detector API** at port 8003 for message quality assurance
- **Prospect Database** at `Documents/recruiter_prospects.csv`
- **Message Templates** at `Documents/recruiter_messages_*.md`
- **Claude-in-Chrome MCP** for Gmail automation (Phase 5)

## Execution Framework

### Phase 1: Pre-flight Checks

**Objective**: Verify all prerequisites before attempting service startup.

**Steps** (execute in order):
1. CHECK that Corporate Council `.env` exists at `D:\Projects\corporate-council\.env`
2. VERIFY `COUNCIL_OPENROUTER_API_KEY` is set (do NOT print the value)
3. CONFIRM claude-dev-cli is installed by running `claude-dev --version`
4. VERIFY Python 3.11+ is available via `python --version`
5. VERIFY Node.js 18+ is available via `node --version`
6. CHECK PostgreSQL service is running via `pg_isready`
7. SCAN ports 8001, 8002, 8003, 8765 for availability

**Success Criteria**:
- All 7 checks return positive results
- No blocked ports detected
- All required environment variables are set

**Failure Action**: HALT and report specific failure with remediation from Troubleshooting table.

---

### Phase 2: Core Services (Required)

**Objective**: Start the minimum required services for development work.

**Steps** (execute in order):
1. SET `PYTHONPATH=D:\Projects\corporate-council\src`
2. START Corporate Council backend on port 8002:
   ```powershell
   python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload
   ```
3. WAIT for server to report "Application startup complete"
4. ~~START Corporate Council frontend (port 5173)~~ **TODO - Not yet implemented**
5. VERIFY claude-dev-cli is accessible via `claude-dev status`

**Success Criteria**:
- Corporate Council backend process is running
- Port 8002 is bound and accepting connections
- claude-dev-cli responds to commands

**Failure Action**: If backend fails to start, check .env file and PYTHONPATH. Report error message.

---

### Phase 3: Optional Services

**Objective**: Start additional services based on user flags.

**Conditional Steps**:

**If `-All` flag is set**:
1. START Life OS Dashboard backend on port 8001:
   ```powershell
   cd D:\Projects\life-os-dashboard && python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload
   ```
2. START Life OS Dashboard frontend on port 3000:
   ```powershell
   cd D:\Projects\life-os-frontend && npm run dev
   ```
3. START Memory MCP server on port 8765:
   ```powershell
   cd D:\Projects\memory-mcp-triple-system && python -m memory_mcp.server
   ```

**If `-Outreach` flag is set**:
4. START Slop Detector on port 8003:
   ```powershell
   cd D:\Projects\slop-detector && python -m uvicorn app.main:app --host 0.0.0.0 --port 8003 --reload
   ```

**Success Criteria**:
- All flagged services start without errors
- Each service binds to its designated port

---

### Phase 4: Health Verification

**Objective**: Confirm all started services are functional.

**Steps** (execute for each started service):
1. SEND HTTP GET request to health endpoint
2. WAIT up to 30 seconds for response
3. VERIFY response status is 200 OK

**Health Endpoints**:
| Service | Health URL |
|---------|-----------|
| Corporate Council | `http://localhost:8002/health` |
| Life OS Dashboard API | `http://localhost:8001/health` |
| Memory MCP | `http://localhost:8765/health` |
| Slop Detector | `http://localhost:8003/health` |

**Success Criteria**:
- All health checks return 200 OK within 30 seconds
- No timeout errors

**Failure Action**: Mark service as failed, continue with remaining checks, report all failures at end.

---

### Phase 5: Status Report

**Objective**: Provide clear summary of startup results.

**Steps**:
1. DISPLAY startup report with counts (running/failed/skipped)
2. LIST all service URLs with their status
3. OPEN browser to `http://localhost:8002/docs` (API documentation)
4. DISPLAY shutdown instructions

**Output Format**:
```
=== STARTUP COMPLETE ===
Services Running: X/Y
Services Failed: Z
Services Skipped: W

[Service URLs with status]

To shutdown: [instructions]
```

**Success Criteria**:
- Report displays complete and accurate status
- Browser opens to API docs (if services are running)

## Quick Commands

```powershell
# ==========================================
# Corporate Council Backend (Primary)
# ==========================================
cd D:\Projects\corporate-council
$env:PYTHONPATH = "D:\Projects\corporate-council\src"
python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload

# Or using bash
cd D:/Projects/corporate-council && PYTHONPATH=src python -m uvicorn council.api.main:app --host 0.0.0.0 --port 8002 --reload

# ==========================================
# Verify Services
# ==========================================
# Health check
curl http://localhost:8002/health

# API docs in browser
Start-Process "http://localhost:8002/docs"

# Test deliberation
Invoke-RestMethod -Uri "http://localhost:8002/api/v1/debates" -Method POST -ContentType "application/json" -Body '{"question":"Should we expand to Asia?","question_type":"STRATEGIC","urgency":"THIS_WEEK"}'

# ==========================================
# claude-dev-cli
# ==========================================
claude-dev status
claude-dev quality analyze D:\Projects\corporate-council\src\council

# ==========================================
# Memory MCP (optional)
# ==========================================
cd D:\Projects\memory-mcp-triple-system
python -m memory_mcp.server

# ==========================================
# Life OS Dashboard (optional)
# ==========================================
# Backend
cd D:\Projects\life-os-dashboard
python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload

# Frontend
cd D:\Projects\life-os-frontend
npm run dev
```

## Service URLs

| Service | URL | Purpose |
|---------|-----|---------|
| Council API | http://localhost:8002 | Council REST API |
| Council Docs | http://localhost:8002/docs | Swagger/OpenAPI docs |
| Council Health | http://localhost:8002/health | Service status |
| Council Debates | http://localhost:8002/api/v1/debates | Create/list debates |
| Council Sessions | http://localhost:8002/api/v1/sessions | Session status |
| Life OS Dashboard | http://localhost:3000 | Task/Project management |
| Life OS API | http://localhost:8001 | Dashboard backend |
| Memory MCP | http://localhost:8765 | Cross-session memory |
| Slop Detector | http://localhost:8003 | Outreach message QA |

**Note**: Council Frontend (Vite+React) at :5173 is TODO - not yet implemented.

## Startup Order

```
1. PostgreSQL (external dependency - sparc_dashboard db)
   |
2. Corporate Council Backend (:8002)
   |
3. claude-dev-cli verification
   |
4. [Optional] Memory MCP (:8765)
   |
5. [Optional] Life OS Dashboard (:8001, :3000)
   |
6. [Optional] Slop Detector (:8003) for outreach
   |
7. Browser to :8002/docs
```

## Pre-requisites

| Requirement | Check Command | Install |
|-------------|---------------|---------|
| Python 3.11+ | `python --version` | winget install Python.Python.3.11 |
| Node.js 18+ | `node --version` | winget install OpenJS.NodeJS |
| PostgreSQL | `pg_isready` | winget install PostgreSQL.PostgreSQL |
| claude-dev-cli | `claude-dev --version` | `pip install -e D:\Projects\claude-dev-cli` |

## Environment Files

| Project | Env File | Template |
|---------|----------|----------|
| Corporate Council | `D:\Projects\corporate-council\.env` | `.env.example` |
| Life OS Dashboard | `D:\Projects\life-os-dashboard\.env` | `.env.example` |
| Memory MCP | `D:\Projects\memory-mcp-triple-system\.env` | `.env.example` |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Port 8002 in use | Kill process: `netstat -ano | findstr :8002` then `taskkill /PID <pid> /F` |
| claude-dev not found | Install: `pip install -e D:\Projects\claude-dev-cli` |
| PostgreSQL not running | Start service: `net start postgresql-x64-15` |
| Memory MCP fails | Check ChromaDB: `pip install chromadb` |
| Import errors | Set `PYTHONPATH=D:\Projects\corporate-council\src` |
| 400 Bad Request | Check model names in `config/advisors.py` match OpenRouter |
| Advisor timeouts | Increase `DEFAULT_ADVISOR_TIMEOUT` in `orchestrator.py` (default: 45s) |
| Database connection fails | Start PostgreSQL, check `.env` credentials |
| Redis auth error | Normal - falls back to in-memory circuit breaker |
| `.env` missing | Copy `.env.example` to `.env`, add `COUNCIL_OPENROUTER_API_KEY` |

## Shutdown

```powershell
# Close all terminal windows opened by startup script
# Or use Ctrl+C in each terminal

# To kill specific port:
$port = 8002
$pid = (Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue).OwningProcess
if ($pid) { Stop-Process -Id $pid -Force }
```

## Verification Checklist

- [ ] `.env` exists with valid `COUNCIL_OPENROUTER_API_KEY`
- [ ] PostgreSQL database accessible (sparc_dashboard)
- [ ] Corporate Council backend responding at :8002
- [ ] Health endpoint returns OK: `GET http://localhost:8002/health`
- [ ] API docs accessible at :8002/docs
- [ ] claude-dev CLI accessible (`claude-dev --version`)
- [ ] Test deliberation returns session_id
- [ ] [Optional] Memory MCP operational at :8765
- [ ] [Optional] Life OS Dashboard at :3000

## Integration with Daily Workflow

This skill is designed for the "morning startup" pattern:

1. `/startup` - Launch full ecosystem
2. Check `claude-dev status` for pending tasks
3. Open council frontend for AI advisory queries
4. Begin development work

### Outreach Workflow

When running recruiter outreach campaigns:

1. `/startup -Outreach` - Launch ecosystem with Slop Detector
2. Use `/recruiter-outreach-pipeline` skill for 7-phase campaign execution
3. Phase 3 (QA) calls Slop Detector at http://localhost:8003/analyze
4. Phase 5 (Send) uses Claude-in-Chrome MCP for Gmail automation

### Related Skills

| Skill | Purpose |
|-------|---------|
| `/council` | Open Corporate Council project only |
| `/recruiter-outreach-pipeline` | 7-phase recruiter cold outreach |

## Examples

### Example 1: Standard Morning Startup

**Scenario**: Developer starts their workday and needs the full development environment.

**User Input**: `/startup`

**Execution**:
```powershell
# Phase 1: Pre-flight checks
> Checking .env files...
  [PASS] D:\Projects\corporate-council\.env exists
  [PASS] COUNCIL_OPENROUTER_API_KEY is set
> Checking port availability...
  [PASS] Port 8002 is available
> Checking dependencies...
  [PASS] Python 3.11.9 detected
  [PASS] Node.js 18.17.0 detected
  [PASS] PostgreSQL service running

# Phase 2: Launch core services
> Starting Corporate Council backend on port 8002...
  [OK] Server running at http://localhost:8002
> Verifying claude-dev-cli...
  [OK] claude-dev v0.5.2 accessible

# Phase 4: Health verification
> Running health checks...
  [PASS] http://localhost:8002/health returned 200 OK

# Phase 5: Status report
=== STARTUP COMPLETE ===
Services Running: 2/2
- Corporate Council Backend: http://localhost:8002
- claude-dev-cli: Ready

Opening browser to http://localhost:8002/docs
```

**Success Criteria**:
- All health checks return 200 OK within 30 seconds
- Browser opens to API documentation
- No error messages in terminal output

---

### Example 2: Full Environment with Outreach Pipeline

**Scenario**: Developer needs all services including Slop Detector for recruiter outreach work.

**User Input**: `/startup -All -Outreach`

**Execution**:
```powershell
# Phase 1-2: Standard startup (abbreviated)
> [PASS] All pre-flight checks passed
> [OK] Corporate Council backend running on :8002

# Phase 3: Optional services
> Starting Memory MCP server on port 8765...
  [OK] Server running at http://localhost:8765
> Starting Life OS Dashboard backend on port 8001...
  [OK] Server running at http://localhost:8001
> Starting Life OS Dashboard frontend on port 3000...
  [OK] Server running at http://localhost:3000
> Starting Slop Detector on port 8003...
  [OK] Server running at http://localhost:8003

# Phase 5: Status report
=== STARTUP COMPLETE ===
Services Running: 5/5
- Corporate Council Backend: http://localhost:8002
- Memory MCP: http://localhost:8765
- Life OS Dashboard API: http://localhost:8001
- Life OS Dashboard UI: http://localhost:3000
- Slop Detector: http://localhost:8003

Ready for recruiter outreach pipeline at http://localhost:8003/analyze
```

**Success Criteria**:
- All 5 services respond to health checks
- Slop Detector /analyze endpoint is accessible
- Life OS Dashboard UI loads in browser

---

### Example 3: Health Check Only (No Service Start)

**Scenario**: Developer wants to verify environment status without starting new processes.

**User Input**: `/startup -HealthOnly`

**Execution**:
```powershell
# Health-only mode - checking existing services
> Scanning for running services...

=== ENVIRONMENT STATUS ===
PostgreSQL: [RUNNING] on port 5432
Corporate Council Backend: [NOT RUNNING]
Memory MCP: [NOT RUNNING]
Life OS Dashboard: [NOT RUNNING]
Slop Detector: [NOT RUNNING]
claude-dev-cli: [INSTALLED] v0.5.2

=== ENVIRONMENT FILES ===
D:\Projects\corporate-council\.env: [EXISTS]
D:\Projects\life-os-dashboard\.env: [EXISTS]
D:\Projects\memory-mcp-triple-system\.env: [EXISTS]

=== PORT AVAILABILITY ===
Port 8001: [AVAILABLE]
Port 8002: [AVAILABLE]
Port 8003: [AVAILABLE]
Port 8765: [AVAILABLE]

Environment ready for startup. Run `/startup` to launch services.
```

**Success Criteria**:
- No services are started or modified
- Complete environment status report generated
- Clear indication of what is available vs running

## Common Anti-Patterns

| Anti-Pattern | Problem | Solution |
|--------------|---------|----------|
| **Starting without .env check** | Services fail silently or expose missing key errors | ALWAYS run Phase 1 pre-flight checks first |
| **Ignoring port conflicts** | Services crash or bind to wrong ports | Check port availability before each service start |
| **Skipping health verification** | Services appear running but are not functional | ALWAYS verify /health endpoint responds 200 OK |
| **Launching all at once** | Race conditions, dependency failures | Follow strict startup order (database-dependent last) |
| **Hardcoding API keys** | Security vulnerability, key exposure | Use .env files exclusively, never inline keys |
| **Starting frontend before backend** | Frontend shows connection errors | Backend must be healthy before frontend launch |

## What NOT to Do

1. **DO NOT** run services without checking `.env` files first
   - Wrong: `python -m uvicorn council.api.main:app` (may fail if COUNCIL_OPENROUTER_API_KEY missing)
   - Right: Check `.env` exists and has required keys, THEN start service

2. **DO NOT** skip health checks and assume services are running
   - Wrong: Start service and immediately open browser
   - Right: Wait for health check to pass before declaring service ready

3. **DO NOT** start multiple services on the same port
   - Wrong: Start Slop Detector on 8002 when Council is already on 8002
   - Right: Each service has dedicated port assignment per Systems Overview table

4. **DO NOT** kill services without checking for dependent processes
   - Wrong: `taskkill /F /PID <pid>` on database when dashboard is connected
   - Right: Shutdown in reverse dependency order (frontend -> backend -> database)

5. **DO NOT** expose sensitive environment variables in output
   - Wrong: `echo $COUNCIL_OPENROUTER_API_KEY`
   - Right: Check if key exists without printing value: `if ($env:COUNCIL_OPENROUTER_API_KEY) { "Key set" }`

## Recent Updates (v2.1.0)

- Updated Corporate Council backend port from 8000 to 8002
- Updated Slop Detector port from 8002 to 8003 (avoid collision)
- Added OpenRouter-specific troubleshooting
- Added environment variable requirements (COUNCIL_OPENROUTER_API_KEY)
- Noted frontend is TODO (not yet implemented)
- Added comprehensive Quick Commands with curl/PowerShell examples
- Updated verification checklist with actual endpoints
- **v2.1.0**: Added Input/Output Contracts per skill-forge v2.0 standards
- **v2.1.0**: Added 3 concrete Examples with success criteria
- **v2.1.0**: Added Common Anti-Patterns table
- **v2.1.0**: Added "What NOT to Do" negative examples section
- **v2.1.0**: Enhanced YAML frontmatter with full cognitive frames and MCP tags
- **v2.1.0**: Added Completion Verification checklist

## Cross-Skill Coordination

### Upstream Skills (provide input to startup)
| Skill | When Used Before | What It Provides |
|-------|------------------|------------------|
| None | N/A | startup is typically first in workflow |

### Downstream Skills (use startup output)
| Skill | When Used After | What It Does |
|-------|-----------------|--------------|
| `/council` | After startup | Interact with Corporate Council API |
| `/recruiter-outreach-pipeline` | After `-Outreach` flag | Execute 7-phase outreach campaign |
| `claude-dev quality` | After startup | Run quality analysis on projects |

### Parallel Skills (work alongside)
| Skill | When Used Together | How They Coordinate |
|-------|-------------------|---------------------|
| `/reflect` | End of session | Captures startup learnings |
| `/mcp` | Service management | Memory MCP integration |

## MCP Requirements

| MCP Server | Required | Why |
|------------|----------|-----|
| memory-mcp | Optional | Cross-session state persistence for startup patterns |
| sequential-thinking | No | Not needed for startup procedures |

**Memory MCP Integration**:
- Store successful startup configurations in `skills/projects/startup` namespace
- Retrieve previous startup failures to suggest remediation
- Tag all writes with `WHO=startup-skill`, `WHY=ecosystem-launch`

## Recursive Improvement

**Role in Meta-Loop**: Startup skill captures environment patterns that inform other skills:
- Failed service starts trigger pattern storage in Memory MCP
- Successful configurations become baseline for future sessions
- Port conflicts and .env issues are logged for trend analysis

**Eval Harness**: Run `claude-dev quality analyze D:\Projects\corporate-council` post-startup to verify code quality.

**Memory Namespace**: `skills/projects/startup`

## Completion Verification

Execute this checklist BEFORE declaring startup complete:

### Phase 1: Pre-flight (MUST ALL PASS)
- [ ] `.env` file exists at `D:\Projects\corporate-council\.env`
- [ ] `COUNCIL_OPENROUTER_API_KEY` environment variable is set (do NOT print value)
- [ ] PostgreSQL service is running (`pg_isready` returns success)
- [ ] Python 3.11+ is available (`python --version`)
- [ ] Node.js 18+ is available (`node --version`)
- [ ] All target ports are available (8001, 8002, 8003, 8765)

### Phase 2: Core Services (MUST ALL PASS)
- [ ] Corporate Council backend started on port 8002
- [ ] Health check `GET http://localhost:8002/health` returns 200 OK
- [ ] `claude-dev --version` returns valid version

### Phase 3: Optional Services (if flags set)
- [ ] Memory MCP started on port 8765 (if `-All`)
- [ ] Life OS Dashboard backend started on port 8001 (if `-All`)
- [ ] Life OS Dashboard frontend started on port 3000 (if `-All`)
- [ ] Slop Detector started on port 8003 (if `-Outreach`)

### Phase 4: Health Verification (MUST ALL PASS)
- [ ] All started services respond to health checks within 30 seconds
- [ ] No services reported errors in terminal output
- [ ] Browser opened to `http://localhost:8002/docs`

### Phase 5: Status Report (MUST COMPLETE)
- [ ] Startup report displayed with running/failed/skipped counts
- [ ] All service URLs listed with status
- [ ] Shutdown instructions provided

**Failure Handling**: If ANY Phase 1 or Phase 2 check fails, HALT startup and report the specific failure with remediation steps from the Troubleshooting table.

Confidence: 0.92 (ceiling: observation 0.95) - Startup skill v2.1.0 upgraded to skill-forge v2.0 standards.

---

## LEARNED PATTERNS

### High Confidence [conf:0.90]
- Corporate Council backend ALWAYS runs on port 8002 [ground:council-v2:2026-01-08]
- Slop Detector should use port 8003 (8002 now taken by Council) [ground:port-collision-fix:2026-01-08]
- Pre-flight checks prevent 90%+ of startup failures [ground:observation:2026-01-08]

### Medium Confidence [conf:0.75]
- Health check timeout of 30 seconds is sufficient for all services [ground:observation:2026-01-08]
- Starting services in dependency order eliminates race conditions [ground:observation:2026-01-08]

### Low Confidence [conf:0.55]
- Council frontend (Vite+React at :5173) is TODO - not yet implemented [ground:codebase-observation:2026-01-08]

---

*Promise: `<promise>STARTUP_SKILL_V2.1.0_SKILL_FORGE_COMPLIANT</promise>`*
