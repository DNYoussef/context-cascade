---
name: language-specialists
description: Route language-specific engineering work to the right specialist and maintain language playbooks.
---




---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Identify language-specific needs, select the correct specialist (Python or TypeScript), and ensure playbooks/examples/tests stay current.

### Library Component References

Before implementing, check these library components:
- `money-handling` - CRITICAL: Decimal-only currency handling (`library.patterns.money_handling`)
- `banking-models` - Banking data models (`library.components.banking.models`)
- `transaction-categorizer` - ML-based categorization (`library.components.accounting.categorizer`)
- `circuit-breaker-trading` - Trading circuit breakers (`library.components.trading.circuit_breakers`)
- `gate-system-manager` - Capital-based gate system (`library.components.trading.gate_system`)
- `kelly-criterion-calculator` - Position sizing (`library.components.trading.position_sizing`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Triggers
- **Positive:** Requests that specify a target language stack or need language-tailored guidance.
- **Negative:** Framework-agnostic prompts (use prompt-architect) or non-language-specific architecture (system-design-architect).

### Guardrails
- Structure-first: maintain `SKILL.md`, `readme`, `examples/`, `tests/`, `resources/`; ensure child specialists mirror this structure.
- Constraint hygiene: extract HARD/SOFT/INFERRED needs (runtime, frameworks, tooling, quality gates).
- Routing safety: only assign to specialists with intact docs; flag missing artifacts.
- Confidence ceiling on routing decisions (inference/report 0.70; research 0.85; observation/definition 0.95).

### Execution Phases
1. **Intake**: Capture language, framework, runtime, and constraints (quality, performance, deployment targets).
2. **Routing**: Choose `python-specialist` or `typescript-specialist`; include backup and escalation path.
3. **Handoff**: Provide context, constraints, and existing examples/tests relevant to the stack.
4. **Validation**: Confirm outputs meet language-specific standards (formatters, linters, test matrices).

### Output Format
- Routing decision with constraints (HARD/SOFT/INFERRED).
- Selected specialist + reasoning and validation checks.
- Confidence statement with ceiling.

### Validation Checklist
- [ ] Constraints captured and confirmed.
- [ ] Specialist selected from registry with healthy docs.
- [ ] Examples/tests referenced or gaps flagged.
- [ ] Confidence ceiling stated.

## VCL COMPLIANCE APPENDIX (Internal)
[[HON:teineigo]] [[MOR:root:D-L]] [[COM:Dil+Yonetim]] [[CLS:ge_meta_skill]] [[EVD:-DI<gozlem>]] [[ASP:nesov.]] [[SPC:path:/skills/specialists/language-specialists]]

[[HON:teineigo]] [[MOR:root:E-P-S]] [[COM:Epistemik+Tavan]] [[CLS:ge_rule]] [[EVD:-DI<gozlem>]] [[ASP:nesov.]] [[SPC:coord:EVD-CONF]]


Confidence: 0.71 (ceiling: inference 0.70) - SOP rebuilt using prompt-architect routing clarity and skill-forge structure-first rules.
