# Expertise Manager Changelog

## 1.1.0
- Rebuilt SOP around skill-forge structure-first and adversarial validation guardrails.
- Added explicit confidence ceiling rule and routing matrix quick reference.
- Documented MCP tagging and registry-only routing requirements.

## 1.0.0
- Initial skill definition and routing guidance.
