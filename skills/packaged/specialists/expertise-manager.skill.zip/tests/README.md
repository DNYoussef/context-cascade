# Expertise Manager Tests

Document adversarial routing cases, coverage gap detection, and escalation path checks. Use these tests to validate that only registered skills are selected, missing docs are flagged, and confidence ceilings are present.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder to keep structure-first guardrails intact.
