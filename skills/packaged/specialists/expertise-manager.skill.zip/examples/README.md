# Expertise Manager Examples

Capture routing scenarios (ambiguous requests, overlapping specialists, missing docs) and show how constraints are extracted, skills are selected, and confidence ceilings are reported. Each example should include validation notes and escalation paths.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder added to satisfy structure-first requirements.
