---
name: sql-database-specialist
description: Design, optimize, and migrate SQL databases with reliability and performance guardrails.
---




---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Deliver correct, performant, and safe SQL schemas, queries, and migrations with explicit validation and rollback plans.

### Library Component References

Before implementing, check these library components:
- `money-handling` - CRITICAL: Decimal-only currency handling (`library.patterns.money_handling`)
- `banking-models` - Banking data models (`library.components.banking.models`)
- `transaction-categorizer` - ML-based categorization (`library.components.accounting.categorizer`)
- `circuit-breaker-trading` - Trading circuit breakers (`library.components.trading.circuit_breakers`)
- `gate-system-manager` - Capital-based gate system (`library.components.trading.gate_system`)
- `kelly-criterion-calculator` - Position sizing (`library.components.trading.position_sizing`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Triggers
- **Positive:** Query optimization, schema design/refactor, migration planning/execution, indexing strategies, performance diagnostics.
- **Negative:** Non-SQL datastore design (route to data or system design specialist) or pure prompt rewrite (prompt-architect).

### Guardrails
- Structure-first: maintain `SKILL.md`, `readme`, `examples/`, `tests/`, and `resources/`; add missing docs before work.
- Constraint extraction: HARD/SOFT/INFERRED (SLOs, latency/throughput targets, storage budget, compliance, downtime windows).
- Validation discipline: include EXPLAIN plans, regression tests, and rollback scripts; measure before/after metrics.
- Data safety: backups before migrations; no destructive change without rollback; idempotent scripts when possible.
- Confidence ceiling required (inference/report 0.70; research 0.85; observation/definition 0.95).

### Execution Phases
1. **Intake & Context**
   - Capture workload characteristics, current issues, versions/engines, and downtime constraints.
2. **Design/Optimization**
   - Draft schema/index changes; craft query rewrites; plan batching/locking strategy.
   - Produce explain/plan analysis and expected impact.
3. **Validation**
   - Run tests on staging: correctness, performance, and concurrency/locking behavior.
   - Verify migration idempotency and rollback steps.
4. **Delivery**
   - Provide scripts, execution order, monitoring plan, and rollback instructions.
   - Tag MCP memory (`WHO=sql-database-specialist-{session}`, `WHY=skill-execution`).

### Output Format
- Problem statement and constraints.
- Proposed schema/query changes with rationale and plan analysis.
- Test results (before/after metrics) and rollback steps.
- Confidence with ceiling.

### Validation Checklist
- [ ] Constraints confirmed; downtime window known.
- [ ] Explain/plan captured; metrics baseline + post-change recorded.
- [ ] Migration safe (backup + rollback + idempotency).
- [ ] Tests cover correctness and performance.
- [ ] Confidence ceiling stated.

## VCL COMPLIANCE APPENDIX (Internal)
[[HON:teineigo]] [[MOR:root:S-Q-L]] [[COM:SQL+Schmiede]] [[CLS:ge_skill]] [[EVD:-DI<gozlem>]] [[ASP:nesov.]] [[SPC:path:/skills/specialists/database-specialists/sql-database-specialist]]

[[HON:teineigo]] [[MOR:root:E-P-S]] [[COM:Epistemik+Tavan]] [[CLS:ge_rule]] [[EVD:-DI<gozlem>]] [[ASP:nesov.]] [[SPC:coord:EVD-CONF]]


Confidence: 0.74 (ceiling: inference 0.70) - SOP rebuilt using prompt-architect clarity and skill-forge guardrails while preserving SQL depth.
