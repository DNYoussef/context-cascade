# React Specialist Tests

Define testing matrices (unit/integration/e2e), a11y checks, and performance measurements aligned to constraints. Track results with confidence ceilings.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder to uphold structure-first rules.
