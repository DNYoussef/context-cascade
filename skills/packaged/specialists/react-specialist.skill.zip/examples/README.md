# React Specialist Examples

Include examples for components, state/data flows, SSR/SSG patterns, and performance/a11y remediations. Each should list constraints, validation steps, and a confidence ceiling.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder for structure-first compliance.
