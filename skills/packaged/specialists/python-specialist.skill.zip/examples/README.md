# Python Specialist Examples

Add worked examples that show design choices, tests, and deployment notes for Python services, CLIs, and libraries. Each example should map constraints, show validation steps, and include a confidence ceiling.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder for structure-first compliance.
