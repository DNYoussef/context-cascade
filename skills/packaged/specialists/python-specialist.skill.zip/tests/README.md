# Python Specialist Tests

Document how to run and interpret lint/format/type/test suites plus perf/security spot checks. Every test plan should tie back to constraints and record confidence with ceiling.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder to meet structure-first rules.
