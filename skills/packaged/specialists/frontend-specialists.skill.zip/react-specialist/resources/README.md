# React Specialist Resources

Centralize templates/snippets for routing, data fetching, state management, a11y checks, and performance profiling. Note validation status and confidence ceilings.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder to maintain structure-first compliance.
