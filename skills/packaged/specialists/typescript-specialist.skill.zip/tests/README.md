# TypeScript Specialist Tests

Describe how to run lint/format/type/test suites and bundle/performance checks. Tie each test to constraints and record confidence ceilings.

Confidence: 0.70 (ceiling: inference 0.70) - Placeholder to enforce structure-first rules.
