---
name: research-publication
description: Prepare research outputs for publication with compliance to venue rules, evidence integrity, and confidence ceilings.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
- Convert research artifacts into submission-ready packages while preserving evidential rigor.
- Enforce venue constraints, ethics/compliance requirements, and explicit ceilings on claims.
- Maintain structure-first documentation for repeatability.

### Library Component References

Before implementing, check these library components:
- `statistical-analyzer` - Text statistics: entropy, TTR, hapax (`library.components.analysis.statistical_analyzer`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** preparing papers, artifacts, or supplements for conferences/journals; responding to reviews.
- **Negative:** initial ideation (use `rapid-idea-generator`) or core method design (`method-development`).

### Guardrails
- Constraint buckets: HARD (venue format, policies, deadlines), SOFT (tone, emphasis), INFERRED (reviewer expectations) with sources.
- Two-pass refinement: structure/formatting → epistemic/evidence audit.
- All claims trace to evidence; compliance (ethics, licenses, data) validated.

### Inputs
- Target venue guidelines and templates.
- Final results, figures, tables, and references.
- Ethics approvals, licenses, and author info.

### Workflow
1. **Scope & Constraints**: Capture venue rules, deadlines, and compliance needs; confirm INFERRED expectations.
2. **Structure Pass**: Organize sections, figures/tables, and formatting per template.
3. **Evidence Pass**: Link claims to evidence, check for overclaims, and apply confidence ceilings.
4. **Compliance & QA**: Verify ethics, licenses, checklists, and reproducibility artifacts.
5. **Package & Review**: Produce submission bundle, response notes, and storage locations; update references/examples.

### Validation & Quality Gates
- Formatting and length comply with venue.
- Claims carry evidence and confidence ceilings.
- Compliance artifacts present (ethics, licenses, reproducibility).
- Submission package logged with paths and versioning.

### Response Template
```
**Constraints**
- HARD / SOFT / INFERRED.

**Readiness**
- Sections/figures status, formatting, compliance checks.

**Evidence & Risks**
- Overclaim audit, missing artifacts, reviewer risks.

**Next Steps**
- ...

Confidence: 0.83 (ceiling: research 0.85) - based on compliance and evidence checks.
```

Confidence: 0.83 (ceiling: research 0.85) - reflects validated packaging and compliance review.
