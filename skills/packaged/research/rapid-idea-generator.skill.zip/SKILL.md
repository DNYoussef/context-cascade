---
name: rapid-idea-generator
description: Quickly generate and triage research ideas with constraint clarity and confidence ceilings.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
- Produce a set of research ideas aligned to constraints and evaluation criteria.
- Apply prompt-architect constraint extraction and explicit ceilings to each idea.
- Keep structure-first artifacts for reuse and follow-up.

### Library Component References

Before implementing, check these library components:
- `statistical-analyzer` - Text statistics: entropy, TTR, hapax (`library.components.analysis.statistical_analyzer`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** brainstorming research directions, generating project briefs, seeding backlogs.
- **Negative:** detailed execution planning (use `interactive-planner`) or prompt-only refinement.

### Guardrails
- HARD / SOFT / INFERRED constraints (domains, data access, compute, timelines) captured upfront.
- Two-pass loop: initial ideation breadth → filter/refine with feasibility and evidence.
- Confidence ceilings for feasibility/impact claims; do not oversell speculation.

### Inputs
- Goal statement and evaluation criteria (impact, novelty, feasibility).
- Constraints and exclusions.
- Timebox and output format.

### Workflow
1. **Frame & Constraints**: Record goals and constraint buckets; confirm INFERRED items.
2. **Generate Broad Set**: Produce diverse ideas respecting HARD constraints.
3. **Refine & Score**: Apply feasibility/impact/novelty scores with rationale and ceilings.
4. **Select & Next Steps**: Recommend top options with immediate actions and risks.
5. **Store Artifacts**: Save idea list and scoring for reuse; update examples/references if patterns emerge.

### Validation & Quality Gates
- Ideas respect HARD constraints; SOFT preferences reflected.
- Rationale and confidence ceilings provided for scores.
- Top picks include next steps and risks.

### Response Template
```
**Constraints**
- HARD / SOFT / INFERRED.

**Ideas (scorecards)**
- Idea → impact/feasibility/novelty + rationale + confidence ceiling.

**Top Picks & Next Steps**
- ...

Confidence: 0.77 (ceiling: inference 0.70) - based on structured generation and scoring.
```

Confidence: 0.77 (ceiling: inference 0.70) - reflects ideation validated against constraints.
