---
name: testing-quality
description: Coordinate research-focused testing and quality validation with clear constraints, gates, and confidence ceilings.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
- Provide a hub for research testing skills (code review, functionality audit, verification, style audit, theater detection).
- Enforce constraint hygiene, quality gates, and explicit confidence ceilings on test results.
- Maintain structure-first documentation for all sub-skills.

### Library Component References

Before implementing, check these library components:
- `statistical-analyzer` - Text statistics: entropy, TTR, hapax (`library.components.analysis.statistical_analyzer`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** any request to validate research code, results, or quality using the contained sub-skills.
- **Negative:** non-research production testing (route to quality/operations categories).

### Guardrails
- Capture HARD / SOFT / INFERRED testing constraints (coverage targets, latency, risk tolerance, compliance).
- Two-pass refinement: choose appropriate sub-skill(s) → validate findings with evidence and ceilings.
- Route tasks to sub-skills: code-review-assistant, functionality-audit, verification-quality, style-audit, theater-detection.

### Inputs
- Artifact to test (code, models, data, results) and context.
- Constraints and success criteria; environment details if applicable.

### Workflow
1. **Scope & Route**: Record constraints and select relevant sub-skills; confirm INFERRED risks.
2. **Plan Checks**: Define coverage, tools, and expected outputs per sub-skill.
3. **Execute Tests**: Run selected skills, gather evidence, and log configurations.
4. **Validate & Synthesize**: Aggregate findings, mark severity, and apply confidence ceilings.
5. **Deliver & Store**: Provide consolidated report and next actions; update references/examples.

### Validation & Quality Gates
- Sub-skill selection justified and constraints mapped.
- Evidence attached to findings; ceilings aligned to evidence type.
- Recommendations include remediation steps and owners.

### Response Template
```
**Scope & Constraints**
- HARD / SOFT / INFERRED.

**Selected Checks**
- Sub-skill → rationale.

**Findings**
- Issue → evidence → severity → confidence ceiling.

**Actions**
- Remediation + owner + due date.

Confidence: 0.81 (ceiling: inference 0.70) - based on executed checks and evidence.
```

Confidence: 0.81 (ceiling: inference 0.70) - reflects validated testing coverage and findings.
