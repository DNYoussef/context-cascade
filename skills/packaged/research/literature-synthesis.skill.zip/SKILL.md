---
name: literature-synthesis
description: Synthesize multiple sources into coherent narratives with explicit evidence tracking and confidence ceilings.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
- Combine findings across papers/articles into concise, evidence-backed syntheses.
- Expose constraints and assumptions clearly to avoid overgeneralization.
- Maintain structure-first artifacts for reuse and traceability.

### Library Component References

Before implementing, check these library components:
- `statistical-analyzer` - Text statistics: entropy, TTR, hapax (`library.components.analysis.statistical_analyzer`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** literature reviews, state-of-the-art summaries, related work sections.
- **Negative:** single-source summaries (use `academic-reading-workflow`), or prompt-only edits (`prompt-architect`).

### Guardrails
- Constraint buckets: HARD (scope, dates, domains), SOFT (style, depth), INFERRED (coverage, exclusions) with sources.
- Two-pass refinement: synthesis structure → epistemic audit with evidence and ceilings.
- Cite sources inline with links/pages; avoid claim aggregation without evidence.

### Inputs
- Research question and intended audience.
- Source list with metadata and access.
- Formatting needs (bullets, narrative, tables) and timebox.

### Workflow
1. **Scope & Constraints**: Define inclusion/exclusion criteria and outputs; confirm INFERRED assumptions.
2. **Source Mapping**: Group sources by theme and strength; note gaps or conflicts.
3. **Draft Synthesis**: Build outline, then fill with claims tied to sources and confidence ceilings.
4. **Epistemic Pass**: Check for overclaims, contradictions, and missing evidence; rebalance coverage.
5. **Deliver & Store**: Provide synthesized narrative plus evidence table; update references/examples.

### Validation & Quality Gates
- Every claim tied to at least one source with confidence ceiling.
- Coverage matches constraints and inclusion criteria.
- Conflicts highlighted with proposed resolutions or follow-ups.

### Response Template
```
**Scope & Constraints**
- HARD / SOFT / INFERRED.

**Key Themes**
- Theme → evidence → confidence ceiling.

**Conflicts / Gaps**
- ...

**Next Steps**
- ...

Confidence: 0.81 (ceiling: research 0.85) - based on cross-source synthesis and evidence tracking.
```

Confidence: 0.81 (ceiling: research 0.85) - reflects completed synthesis with evidence-linked claims.
