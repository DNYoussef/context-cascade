---
name: visual-asset-generator
description: Generate research visuals (figures, diagrams) with constraints, evidence alignment, and confidence ceilings.
---





---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
- Produce visual assets that accurately reflect research findings and constraints.
- Apply constraint hygiene and explicit ceilings to avoid misrepresentation.
- Maintain structure-first documentation for reproducibility.

### Library Component References

Before implementing, check these library components:
- `statistical-analyzer` - Text statistics: entropy, TTR, hapax (`library.components.analysis.statistical_analyzer`)
- `pattern-matcher` - Generic pattern detection (`library.components.analysis.pattern_matcher`)
- `scoring-aggregator` - Weighted score aggregation (`library.components.analysis.scoring_aggregator`)
- `report-generator` - Multi-format report generation (`library.components.reporting.report_generator`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** requests for figures, diagrams, charts, or schematics tied to research outputs.
- **Negative:** purely aesthetic design work unrelated to research; or text-only summaries.

### Guardrails
- Constraints bucketed: HARD (data accuracy, confidentiality, formats), SOFT (style preferences), INFERRED (audience literacy).
- Two-pass loop: draft visual plan → validate against evidence and constraints.
- Explicitly cite data sources and uncertainty; include confidence ceilings where interpretation is inferred.

### Inputs
- Goal of the visual, target audience, and format requirements.
- Data/metrics to visualize and source locations.
- Style guidance and accessibility needs.

### Workflow
1. **Scope & Constraints**: Capture objectives and constraint buckets; confirm INFERRED assumptions.
2. **Design Plan**: Choose visual types, annotations, and data mappings; check feasibility.
3. **Create Draft**: Build the asset with labeled data sources and units.
4. **Validate**: Verify data accuracy, legends, accessibility, and confidentiality; apply ceilings to interpretive statements.
5. **Deliver & Store**: Provide assets, source files, and usage notes; update references/examples.

### Validation & Quality Gates
- Data sources cited; transformations documented.
- Visual readable and accessible; constraints respected.
- Interpretations include confidence ceilings.

### Response Template
```
**Goal & Constraints**
- HARD / SOFT / INFERRED.

**Design**
- Visual type, data sources, annotations.

**Validation**
- Accuracy checks, accessibility, risks.

**Deliverables**
- Asset paths, source files, usage notes.

Confidence: 0.80 (ceiling: research 0.85) - based on validated visuals and data checks.
```

Confidence: 0.80 (ceiling: research 0.85) - reflects validated visual assets tied to evidence.
