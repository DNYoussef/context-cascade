# Documentation Skill Resources

Store outlines, templates, and captured command outputs that back published documentation.
