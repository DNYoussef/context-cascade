# Documentation Skill References

Capture source-of-truth links (code paths, API specs, ADRs) cited in the documentation deliverables.
