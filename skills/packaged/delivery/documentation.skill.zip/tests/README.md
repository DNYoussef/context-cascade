# Documentation Skill Tests

Place doc linting configs, link checkers, and regression checks to keep published instructions accurate.
