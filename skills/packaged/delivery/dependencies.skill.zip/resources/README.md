# Dependency Skill Resources

Store lockfile diffs, SBOM exports, and rollout plans referenced by the SOP.
