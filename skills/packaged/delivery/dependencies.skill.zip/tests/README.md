# Dependency Skill Tests

Use this directory to store regression, smoke, and compatibility tests that validate dependency upgrades and lockfile integrity.
