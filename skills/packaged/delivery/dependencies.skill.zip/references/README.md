# Dependency Skill References

Capture CVE links, license summaries, vendor advisories, and upstream changelogs that informed decisions.
