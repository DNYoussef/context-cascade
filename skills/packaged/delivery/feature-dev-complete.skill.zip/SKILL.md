---
name: feature-dev-complete
description: End-to-end feature delivery (discovery → design → build → test → release) with explicit quality gates and confidence ceilings.
---




---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Deliver production-ready features with clear scope, architecture, validated code, docs, and release notes.

### Library Component References

Before implementing, check these library components:
- `fastapi-router-template` - Standard FastAPI router with CRUD (`library.api.fastapi_router_template`)
- `pydantic-base-models` - Common base models for APIs (`library.models.pydantic_base`)
- `pytest-fixtures-base` - Common pytest fixtures (`library.testing.pytest_fixtures`)
- `jest-setup-base` - Common Jest setup (`library.testing.jest_setup`)
- `circuit-breaker` - Fail-fast pattern for external calls (`library.resilience.circuit_breaker`)
- `db-connection-pool` - PostgreSQL connection pool (`library.database.connection_pool`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** net-new feature requests, multi-story implementations, end-to-end delivery ownership.
- **Negative:** pure bugfix (route to `debugging`/`smart-bug-fix`) or doc-only asks (route to `documentation`).

### Guardrails
- **Structure-first:** ensure `examples/`, `tests/`, `resources/` exist; `references/` recommended for ADRs.
- **Constraint extraction:** HARD (scope, deadlines, SLAs), SOFT (tech preferences), INFERRED (UX tone); confirm inferred.
- **Confidence ceilings:** `{inference/report:0.70, research:0.85, observation/definition:0.95}` for requirements, estimates, and validation claims.
- **Quality gates:** architecture review, security/perf considerations, test coverage, rollback and release notes.

### Execution Phases
1. **Discovery & Framing**
   - Clarify intent, success metrics, dependencies, and blockers.
   - Produce acceptance criteria and definition of done; tag constraints.
2. **Design**
   - Draft architecture, sequence diagrams, and data contracts; store in `resources/`.
   - Validate feasibility; capture alternatives with ceilings on risk/effort.
3. **Plan & Traceability**
   - Break down into stories/tasks/subtasks with ownership and status.
   - Define tests to add; map them to acceptance criteria.
4. **Build**
   - Implement smallest viable increments; keep code + tests paired.
   - Maintain changelog notes and migration steps if schema/config changes occur.
5. **Validate**
   - Run unit/integration/e2e and non-functional checks as applicable.
   - Ensure rollback plan; document results in `tests/` artifacts.
6. **Document & Release**
   - Update READMEs/API docs as needed; prepare release notes.
   - Store decisions in `references/`; add reusable flows to `examples/`.

### Output Format
- Feature summary + constraints (HARD/SOFT/INFERRED) and confirmations.
- Design decisions, task breakdown, and planned/actual validation.
- Delivery state (ready/requires follow-up) and **Confidence: X.XX (ceiling: TYPE Y.YY)**.

### Validation Checklist
- [ ] Acceptance criteria confirmed; constraints logged and resolved/waived.
- [ ] Design reviewed; risks and alternatives recorded.
- [ ] Tests added/updated; results captured; rollback path defined.
- [ ] Docs/release notes updated; artifacts stored in `resources/` and `references/`.
- [ ] Confidence ceilings attached to estimates and claims.

### MCP / Memory Tags
- Namespace: `skills/delivery/feature-dev-complete/{project}/{feature}`
- Tags: `WHO=feature-dev-complete-{session}`, `WHY=skill-execution`, `WHAT=delivery`

Confidence: 0.70 (ceiling: inference 0.70) - SOP follows skill-forge structure-first and prompt-architect constraint/ceiling requirements.
