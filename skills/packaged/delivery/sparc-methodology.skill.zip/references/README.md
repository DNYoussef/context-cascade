# SPARC Methodology References

Keep ADRs, standards, research links, and evidence sources cited in SPARC artifacts.
