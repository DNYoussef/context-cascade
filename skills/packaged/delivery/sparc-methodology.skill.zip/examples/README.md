# SPARC Methodology Examples

Capture SPARC artifacts (spec, pseudocode, architecture, refinement) for representative deliveries.
