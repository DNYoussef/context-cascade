# SPARC Methodology Resources

Store specifications, diagrams, and decision logs referenced during SPARC execution.
