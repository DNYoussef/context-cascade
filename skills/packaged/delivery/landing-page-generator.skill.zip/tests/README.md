# Landing Page Generator Tests

Use this directory for accessibility, responsiveness, and performance checks that validate landing page builds before deployment.
