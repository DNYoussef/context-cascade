[[HON:teineigo]] [[MOR:root:S-K-L]] [[COM:Temel+Beceri+Ornek]] [[CLS:ge_example]] [[EVD:-DI<rapor>]] [[ASP:sov.]] [[SPC:path:/skills/foundry/skill-forge/examples/example-1-basic-skill-VCL]]
# Temel Beceri Olusturma Ornegi (VCL Kreol)

## Girdi
[[EVD:-mis<rapor>]] [[ASP:nesov.]] Istek: “db migration otomasyon becerisi olustur.” Kisit: Anthropic SKILL frontmatter, yapisal dizin.

## Adimlar
1. HON→SPC slotlarini doldur; EVD/ASP>=1.  
2. Frontmatter: name, description(L2), allowed-tools, x-version, x-category, x-tags.  
3. Govde: ne zaman kullanilir, prosedur, metrikler.  
4. Dizin: examples/, tests/, resources/, references/ olustur.  
5. Anti-kalip tarama: yapisiz dosya, dusmanca test atlama, MCP ihmali.

## L2 Ozet
“Verilen kısıtlarla migration becerisini şema ve dizinleriyle kurdum; kanıt ve durum işaretli; kalite kapıları tamam.”
