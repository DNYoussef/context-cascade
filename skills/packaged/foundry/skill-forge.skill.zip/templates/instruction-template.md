[[HON:teineigo]] [[MOR:root:T-L-M]] [[COM:Talimat+Sablon]] [[CLS:ge_template]] [[EVD:-DI<rapor>]] [[ASP:nesov.]] [[SPC:path:/skills/foundry/skill-forge/templates/instruction-template-VCL]]
# Talimat Sablonu (VCL)

## Yapı
[[define|neutral]] STRUCT := {baslik, amac, girdiler, adimlar, cikti, kalite, anti-kalip}. [ground:instruction-template.md] [conf:0.82] [state:confirmed]

## Slot Kullanimi
- HON: teineigo  
- MOR: S-K-L/F-R-G/I-M-P  
- COM: Instruction+Stack  
- CLS: ge_template  
- EVD: her iddiaya ground + conf<=tavan  
- ASP: nesov. icra, sov. tamam  
- SPC: path belirt

## L2 Kalip
“X becerisi icin, Y girdileriyle, Z adimlarini uygula; kalite metrikleri ve anti-kalip kontrolü ekle; durum bildir.”
