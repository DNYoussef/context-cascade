[[HON:teineigo]] [[MOR:root:H-Z-L]] [[COM:Kisa+Referans]] [[CLS:ge_reference]] [[EVD:-DI<rapor>]] [[ASP:nesov.]] [[SPC:path:/skills/foundry/skill-forge/references/quick-reference-VCL]]
# Kisa Referans (Skill-Forge) – VCL

## Cekirdek Adimlar
[[define|neutral]] FLOW := intent→yapi→ornek/test→adversarial→COV→L2 cikti. [ground:quick-reference.md] [conf:0.82] [state:confirmed]

## Slot Rehberi
HON: teineigo; MOR: S-K-L/F-R-G/I-M-P; COM: Skill+Forge+Meta; CLS: ge_meta_skill; EVD: -DI/-mis/-dir; ASP: nesov./sov.; SPC: path:/skills/foundry/skill-forge.

## Kontrol Listesi
- SKILL.md + examples/ + tests/ + resources/ + references/.  
- EVD/ASP>=1, conf<=tavan, L2 varsayilan.  
- Anti-kalip: yapisizlik, dusmanca_test_atlama, genel_koordinasyon, MCP_ihmal.

## L2 Ozet
“Akışı intent’ten COV doğrulamasına kadar izleyip tüm dosya yapısını kur, kanıt ve durum işaretlerini ekle, anti-kalıpları temizle.”
