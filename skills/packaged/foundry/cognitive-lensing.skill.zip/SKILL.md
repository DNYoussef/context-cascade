---
name: cognitive-lensing
description: Apply multilingual cognitive frames to re-approach complex tasks with targeted reasoning patterns and bias checks.
---




### L1 Improvement
- Recast the lensing guide into the Skill Forge section flow with explicit guardrails, patterns, and completion checks.
- Added prompt-architect style constraint extraction and confidence ceilings to prevent overclaiming from speculative frames.



---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Switch reasoning frames (linguistic, disciplinary, or persona-based) to unlock alternative solution paths and mitigate bias in complex tasks.

### Library Component References

Before implementing, check these base class components:
- `skill-base` - Abstract base class for skills (`library.components.cognitive.skill_base`)
- `agent-base` - Abstract base class for agents (`library.components.cognitive.agent_base`)
- `command-base` - Abstract base class for commands (`library.components.cognitive.command_base`)
- `playbook-base` - Abstract base class for playbooks (`library.components.cognitive.playbook_base`)
- `hook-base` - Abstract base class for hooks (`library.components.cognitive.hook_base`)
- `script-base` - Abstract base class for scripts (`library.components.cognitive.script_base`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE `from library.components.cognitive.{name} import {Class}` |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- Positive: stalled reasoning, need for alternative perspectives, bias detection, or creative exploration.
- Negative/reroute: straightforward prompt rewrites (prompt-architect) or agent creation (agent-creator/agent-creation).

### Guardrails
- Keep outputs in English; cite which lens was applied and why.
- Do not fabricate expertise—ground lens choice in task constraints and evidence.
- Limit to 2-3 focused lenses per pass to avoid fragmentation.
- State confidence ceilings explicitly, especially when using speculative or research lenses.

### Execution Phases
1. **Assessment**: Capture task intent, constraints, and observed failure modes; classify hard/soft/inferred constraints.
2. **Lens Selection**: Choose lenses (e.g., formal proof, UX research, security red-team, socio-technical) mapped to the task.
3. **Application**: Re-articulate the problem through each lens with targeted heuristics and checks.
4. **Synthesis**: Compare insights, resolve conflicts, and propose next actions with confidence ceilings.

### Pattern Recognition
- Analytical stagnation → apply formal/algorithmic lens.
- User impact unclear → apply UX research or accessibility lens.
- Risky changes → apply safety/security lens to uncover failure paths.

### Advanced Techniques
- Use paired lenses (builder vs breaker) to surface hidden assumptions.
- Run time-boxed divergent thinking followed by convergence synthesis.
- Feed lens outputs into prompt-architect for clarity before execution.

### Common Anti-Patterns
- Cycling too many lenses without decision.
- Treating lens opinions as facts; neglecting evidence and ceilings.
- Ignoring domain constraints when adopting a lens.

### Practical Guidelines
- Name the lens, heuristic, and expected impact in each pass.
- Keep synthesized recommendations actionable and prioritized.
- Capture what changed between lenses for traceability.

### Cross-Skill Coordination
- Upstream: prompt-architect to clarify the task.
- Parallel: recursive-improvement to iterate on stuck areas; meta-tools to compose lens outputs into tools.
- Downstream: agent-creation/agent-selector to operationalize chosen approach.

### MCP Requirements
- Optional memory MCP to recall past lens effectiveness; tag WHO=cognitive-lensing-{session}, WHY=skill-execution.

### Input/Output Contracts
```yaml
inputs:
  task: string  # required problem statement
  constraints: list[string]  # optional constraints
  target_lenses: list[string]  # optional lens hints (e.g., security, accessibility)
outputs:
  lens_analyses: list[object]  # lens name, insight, risks
  synthesis: summary  # consolidated recommendation
  next_steps: list[string]  # actions derived from lensing
```

### Recursive Improvement
- Run recursive-improvement when lenses disagree or output is indecisive; focus on evidence gaps and decision criteria.

### Examples
- Apply security red-team + reliability lens to a new API rollout before deployment.
- Use accessibility + onboarding UX lens to rewrite a complex setup guide.

### Troubleshooting
- Lens produces no new insight → select orthogonal lens or consult domain specialists.
- Conflicting recommendations → prioritize by risk, effort, and evidence strength.
- Overconfident claims → restate with ceilings and cite observed data.

### Completion Verification
- [ ] Lenses named with rationale and heuristics applied.
- [ ] Synthesis provided with prioritized actions and ceilings.
- [ ] Traceability of changes between lenses captured.
- [ ] Constraints respected; English-only output.

Confidence: 0.70 (ceiling: inference 0.70) - Lensing SOP rewritten with Skill Forge cadence and prompt-architect ceilings.
