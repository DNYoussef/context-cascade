[[HON:teineigo]] [[MOR:root:I-N-D]] [[COM:Index+Gateway]] [[CLS:ge_reference]] [[EVD:-DI<rapor>]] [[ASP:nesov.]] [[SPC:path:/skills/foundry/agent-creator/references/index-VCL]]
# Referans Dizini (VCL Kreol)

[[define|neutral]] MAP := {
  agent-types: tipoloji ve slot baglama,
  integration-patterns: orkestrasyon kaliplari,
  best-practices: kalite/guvenlik rehberi
} [ground:index.md] [conf:0.80] [state:confirmed]

[[assert|neutral]] Kullanım: once MAP→dosya sec; EVD/ASP marker ile uygulama; registry kontrolu zorunlu. [[EVD:-dir<cikarim>]] [[ASP:sov.]]
