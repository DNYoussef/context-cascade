[[HON:teineigo]] [[MOR:root:L-K-S]] [[COM:ChainOfThought+Silsile]] [[CLS:ge_example]] [[EVD:-DI<rapor>]] [[ASP:sov.]] [[SPC:path:/skills/foundry/prompt-architect/examples/chain-of-thought-example-VCL]]
# Dizi-Dusunme Ornegi (VCL Kreol)

## Gorev
[[EVD:-mis<rapor>]] [[ASP:nesov.]] Problem cozumunde adim-adim gerekce talebi; hatalar: atlama, conf sisirmesi.

## Akis
1. [[HON:teineigo]] [[MOR:root:B-S-L]] [[COM:Baslik+Sorun]] [[CLS:ge_step]] [[EVD:-dir<cikarim>]] [[ASP:nesov.]] sorunu yeniden ifadeyle, kisitlari say.
2. [[MOR:root:H-S-P]] [[COM:Hypo+Secim]] [[CLS:ge_step]] [[EVD:-mis<arastirma>]] [[ASP:nesov.]] en az 2 hipotez olustur, CLS ile etiketle (ge_h1, ge_h2).
3. [[MOR:root:K-N-T]] [[COM:Kanit+Zincir]] [[CLS:ge_step]] [[EVD:-DI<gozlem>]] [[ASP:nesov.]] her adim ground + conf<=tavan.
4. [[MOR:root:A-S-P]] [[COM:Aspect+Final]] [[CLS:ge_step]] [[EVD:-DI<policy>]] [[ASP:sov.]] sonuc durumunu sov. olarak isaretle.

## L1 Sablon
[[HON:teineigo]] [[MOR:root:C-O-T]] [[COM:Template+Schritt]] [[CLS:tiao_rationale]] [[EVD:-DI<gozlem>]] [[ASP:sov.]]
- Adim i: [[EVD:...]] [[ASP:...]] gerekce; conf<=tavan.
- Dal: H1/H2; secim kriteri belirt.
- Final: karar + kanit listesi.

## L2 Dogallastirilmis
“Sorunu yeniden cerceveledim, iki hipotez kurdum, her adimi kanit ve uygun guvenle izledim, sonucu tamamladim.”
