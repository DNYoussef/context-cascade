---
name: advanced-coordination
description: Orchestrate complex, latency-aware multi-agent work with adaptive topologies, resilient routing, and evidence-backed handoffs.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Coordinate advanced agent meshes (hierarchical, mesh, hybrid) for tasks that demand resilience, shared state, and deterministic outcomes without confidence inflation.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `redis-pubsub` - Redis pub/sub for coordination (`library.components.messaging.redis_pubsub`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** multi-agent task graphs, consensus-heavy workflows, topology design, swarm stabilization, resilience drills.
- **Negative:** single-agent execution, static pipelines without delegation, or requests better routed to prompt-forge/agent-creator.

### Guardrails
- **Skill-Forge structure-first:** maintain `SKILL.md`, `examples/`, and `tests/`; add `resources/` and `references/` or log remediation tasks before close.
- **Prompt-Architect hygiene:** capture intent, extract HARD/SOFT/INFERRED constraints, and deliver pure-English outputs with explicit ceilings (inference/report ≤ 0.70).
- **Safety & registry discipline:** register every agent, block cascading failures with circuit breakers/rollback paths, and keep hook latencies under pre/post targets.
- **Adversarial validation:** exercise boundary cases (partition, drop, retry), run COV, and record evidence before marking done.
- **MCP tagging:** persist orchestration notes with WHO=`advanced-coordination-{session}` and WHY=`skill-execution`.

### Execution Playbook
1. **Intent & constraints:** identify objective, environment, SLOs, and non-negotiables; flag inferred constraints for confirmation.
2. **Topology & roles:** choose topology, assign owners, define state channels, retries, and escalation thresholds.
3. **Delegation plan:** break work into routable units, set acceptance criteria per agent, and align timers/quotas.
4. **Safety nets:** pre-mortem failure points, configure rate limits/backoff, and define rollback/abort steps.
5. **Validation loop:** run adversarial drills, measure latency/throughput, verify registry health, and capture telemetry.
6. **Delivery:** summarize decisions, surface risks, enumerate follow-ups, and provide confidence with ceiling notation.

### Output Format
- Activation summary (intent, constraints, triggers).
- Selected topology with roles, data pathways, and guardrails.
- Delegation and timeline with ownership.
- Validation evidence (latency, retries, failure drills) and residual risks.
- **Confidence:** `X.XX (ceiling: TYPE Y.YY) - rationale`.

### Validation Checklist
- Structure-first assets present or ticketed; examples/tests updated or TODO assigned.
- Constraints addressed; registry and hooks within budget; rollback defined.
- Adversarial and COV runs captured with evidence; telemetry stored with MCP tags.
- Confidence ceiling stated; outputs in pure English without VCL leakage.

### Completion Definition
Work is complete when topology is live, agents are healthy, validation results are recorded, residual risks are noted with owners, and MCP notes persist under the session tag.

Confidence: 0.70 (ceiling: inference 0.70) - Rewrite applies skill-forge structure, prompt-architect clarity, and orchestration safety for resilient execution.
