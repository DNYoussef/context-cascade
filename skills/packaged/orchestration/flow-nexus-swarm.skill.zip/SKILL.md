---
name: flow-nexus-swarm
description: Orchestrate cloud-ready swarms on Flow Nexus with adaptive scaling, secure messaging, and validated deployment steps.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Deploy and manage Flow Nexus swarms with topology-aware scaling, secure channel setup, and resilience against cloud-specific failure modes.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `redis-pubsub` - Redis pub/sub for coordination (`library.components.messaging.redis_pubsub`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** Flow Nexus deployments, cloud swarm tuning, scaling/rollback drills, secure channel provisioning, cross-region coordination.
- **Negative:** local-only swarms, non-Flow Nexus requests, or pure prompt shaping (route to prompt-architect).

### Guardrails
- **Skill-Forge structure-first:** ensure `SKILL.md`, `examples/`, `tests/` exist; add `resources/` and `references/` or log remediation.
- **Prompt-Architect clarity:** extract HARD/SOFT/INFERRED constraints (regions, quotas, compliance), use pure English, and declare confidence ceilings.
- **Platform safety:** enforce identity, network, and secret management policies; register agents; keep hook latency within budgets; define rollback for cluster actions.
- **Adversarial validation:** simulate region loss, quota exhaustion, and message drops; record evidence and metrics.
- **MCP tagging:** store swarm runs with WHO=`flow-nexus-swarm-{session}` and WHY=`skill-execution`.

### Execution Playbook
1. **Intent & constraints:** capture targets (capacity, latency, compliance) and confirm inferred platform limits.
2. **Topology & setup:** design swarm layout, provision channels, register agents, and configure autoscaling rules.
3. **Deployment plan:** stage rollout, health checks, and backoff/retry policies; set observability hooks.
4. **Safety nets:** pre-mortem failure points, define rollback and isolation controls; validate secrets and access scopes.
5. **Validation loop:** run adversarial drills (failover, rate limits), measure telemetry, and capture evidence.
6. **Delivery:** present deployment map, validation results, residual risks, and confidence ceiling.

### Output Format
- Deployment objective, constraints, and topology.
- Channel/security setup, autoscaling rules, and rollback paths.
- Validation artifacts (failover, latency, quota tests) and risk log.
- MCP references for persisted notes.
- **Confidence:** `X.XX (ceiling: TYPE Y.YY) - rationale`.

### Validation Checklist
- Structure-first assets present or ticketed; examples/tests updated or planned.
- Identity/secrets validated; registry and hooks healthy; rollback tested.
- Adversarial and COV runs logged with MCP tags; confidence ceiling stated; English-only output.

### Completion Definition
Swarm deployment is complete when topology is live, security and scaling controls are verified, evidence is stored, and remaining risks are owned with next actions.

Confidence: 0.70 (ceiling: inference 0.70) - Flow Nexus orchestration reframed with skill-forge structure and prompt-architect evidence rules for cloud resilience.
