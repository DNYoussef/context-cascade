---
name: ralph-multimodel
description: Extend RALPH loops across multiple models, coordinating roles, evidence, and confidence ceilings per model.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Run multi-model RALPH flows that leverage specialized agents for reasoning, alignment, learning, planning, and handoff with controlled synthesis.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `redis-pubsub` - Redis pub/sub for coordination (`library.components.messaging.redis_pubsub`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** problems needing diverse model strengths, cross-model validation, parallel evidence gathering, and adjudicated synthesis.
- **Negative:** single-model work, prompt-only edits (route to prompt-architect), or new skill creation (route to skill-forge).

### Guardrails
- **Skill-Forge structure-first:** keep `SKILL.md`, `examples/`, `tests/` current; add `resources/`/`references/` or note gaps.
- **Prompt-Architect hygiene:** capture HARD/SOFT/INFERRED constraints per model/phase, avoid VCL leakage, and publish ceilings for confidence.
- **Multi-model safety:** assign roles, enforce registry usage, prevent uncontrolled self-calls, and keep hook latency within budget.
- **Adversarial validation:** run cross-model disagreement checks, COV per synthesis, and boundary tests; document evidence.
- **MCP tagging:** store runs with WHO=`ralph-multimodel-{session}` and WHY=`skill-execution`.

### Execution Playbook
1. **Intent & roster:** define objective, select models/roles, and confirm constraints.
2. **Phase wiring:** map RALPH phases to models, timeboxes, and success metrics.
3. **Deliberation:** gather model outputs, run challenges, and update shared evidence.
4. **Synthesis:** reconcile disagreements, choose outputs, and plan handoff with rollback paths.
5. **Validation loop:** stress-test synthesis, measure performance, and log telemetry.
6. **Delivery:** share decisions, evidence, risks, and confidence ceiling.

### Output Format
- Objective, constraints, and model roster with roles.
- Phase summaries, evidence, and dissent.
- Handoff/rollback plan and risk register.
- **Confidence:** `X.XX (ceiling: TYPE Y.YY) - rationale`.

### Validation Checklist
- Structure-first assets present or ticketed; examples/tests reflect multi-model paths.
- Role boundaries enforced; registry-only agents used; hook budgets verified; rollback ready.
- Adversarial/COV runs logged with MCP tags; confidence ceiling stated; English-only output.

### Completion Definition
Flow is complete when synthesis is chosen with evidence, handoff executes, risks are owned, and logs persist in MCP with session tags.

Confidence: 0.70 (ceiling: inference 0.70) - Multi-model RALPH doc aligned to skill-forge scaffolding and prompt-architect evidence/confidence discipline.
