---
name: coordination
description: Coordinate distributed agents with resilient topologies, synchronized state, and evidence-backed communication patterns.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Deliver reliable multi-agent coordination across meshes, hierarchies, or hybrids while preventing state loss, deadlocks, and confidence overreach.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `redis-pubsub` - Redis pub/sub for coordination (`library.components.messaging.redis_pubsub`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** topology design, agent registration, message routing, consensus or quorum work, partition/latency tolerance needs.
- **Negative:** single-threaded execution, non-coordinated batch work, or prompt-only refinement (route to prompt-architect).

### Guardrails
- **Skill-Forge structure-first:** keep `SKILL.md`, `examples/`, and `tests/` current; add `resources/` and `references/` or record remediation tasks.
- **Prompt-Architect clarity:** capture intent and constraints (HARD/SOFT/INFERRED), avoid VCL leakage, and state confidence with ceilings.
- **Coordination safety:** register every agent, validate topology (no orphaned nodes/cycles where forbidden), enforce health checks, and keep hooks within latency budgets.
- **Adversarial validation:** probe partitions, message loss, reconnects, and rate limits; document evidence.
- **MCP tagging:** persist coordination runs with WHO=`coordination-{session}` and WHY=`skill-execution`.

### Execution Playbook
1. **Intent & constraints:** define mission, scale, latency targets, and shared-state rules; confirm inferred needs.
2. **Topology & registry:** select topology, register agents, define namespaces, and configure routing keys.
3. **Delegation & messaging:** set task sharding rules, retries, ack/requeue policies, and escalation paths.
4. **Safety & resilience:** plan for partitions, backpressure, and failover; add circuit breakers and watchdogs.
5. **Validation loop:** run adversarial drills, measure latency/throughput, and verify state convergence.
6. **Delivery:** summarize topology, evidence, residual risks, and confidence ceiling.

### Output Format
- Intent, constraints, and chosen topology.
- Agent registry snapshot, routing schema, and health model.
- Operational plan (sharding, retries, escalation, rollback).
- Validation evidence with metrics; risks and follow-ups.
- **Confidence:** `X.XX (ceiling: TYPE Y.YY) - rationale`.

### Validation Checklist
- Structure-first assets present or queued; examples/tests reflect current patterns.
- Registry complete; health checks and latency budgets verified; rollback path defined.
- Adversarial/COV runs captured with MCP tags; confidence ceiling present; English-only output.

### Completion Definition
Coordination is complete when topology is stable, messaging meets SLOs, validation artifacts are stored, and remaining risks are owned with next steps logged.

Confidence: 0.70 (ceiling: inference 0.70) - Coordination SOP rewritten with skill-forge structure, prompt-architect constraint handling, and resilience guardrails.
