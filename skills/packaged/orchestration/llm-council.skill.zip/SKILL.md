---
name: llm-council
description: Facilitate council-style deliberation among specialized models with structured prompts, evidence gates, and explicit confidence ceilings.
---






---

## LIBRARY-FIRST PROTOCOL (MANDATORY)

**Before writing ANY code, you MUST check:**

### Step 1: Library Catalog
- Location: `.claude/library/catalog.json`
- If match >70%: REUSE or ADAPT

### Step 2: Patterns Guide
- Location: `.claude/docs/inventories/LIBRARY-PATTERNS-GUIDE.md`
- If pattern exists: FOLLOW documented approach

### Step 3: Existing Projects
- Location: `D:\Projects\*`
- If found: EXTRACT and adapt

### Decision Matrix
| Match | Action |
|-------|--------|
| Library >90% | REUSE directly |
| Library 70-90% | ADAPT minimally |
| Pattern exists | FOLLOW pattern |
| In project | EXTRACT |
| No match | BUILD (add to library after) |

---

## STANDARD OPERATING PROCEDURE

### Purpose
Run council deliberations that collect diverse model opinions, enforce evidence-backed synthesis, and prevent overconfident consensus.

### Library Component References

Before implementing, check these library components:
- `pipeline-executor` - DAG-based pipeline execution (`library.components.orchestration.pipeline_executor`)
- `content-pipeline-template` - 11-phase content pipeline (`library.pipelines.content_pipeline`)
- `multi-model-router` - Route to optimal LLM (`library.ai.multi_model_router`)
- `websocket-manager` - WebSocket connection manager (`library.components.realtime.websocket_manager`)
- `redis-pubsub` - Redis pub/sub for coordination (`library.components.messaging.redis_pubsub`)
- `task-scheduler` - Async task scheduling (`library.components.scheduling.task_scheduler`)

**Decision Matrix**:
| Match | Action |
|-------|--------|
| >90% | REUSE from library |
| 70-90% | ADAPT with minimal changes |
| Pattern | FOLLOW documented pattern |
| No match | BUILD new (document decision) |

### Trigger Conditions
- **Positive:** multi-model debate, comparative reasoning, adjudication of conflicting outputs, need for weighted synthesis with evidence.
- **Negative:** single-model answers, pure prompt polishing (route to prompt-architect), or skill creation (route to skill-forge).

### Guardrails
- **Skill-Forge structure-first:** maintain `SKILL.md`, `examples/`, `tests/`; add `resources/` and `references/` or log remediation tasks.
- **Prompt-Architect hygiene:** define intent and constraints per council question; capture HARD/SOFT/INFERRED assumptions; output pure English with explicit ceilings.
- **Council safety:** assign roles (proposer, challenger, judge), enforce registry agents, timebox rounds, and ensure hook latency budgets.
- **Adversarial validation:** require dissenting review, cross-check citations, and COV on synthesis steps; capture evidence.
- **MCP tagging:** store council transcripts with WHO=`llm-council-{session}` and WHY=`skill-execution`.

### Execution Playbook
1. **Intent & scope:** define the question, success metric, and constraints; confirm inferred items.
2. **Panel setup:** select specialists, assign roles, and set scoring criteria; configure timeboxes.
3. **Deliberation rounds:** gather proposals, run adversarial critiques, and request evidence per claim.
4. **Synthesis:** weigh arguments, resolve conflicts, and produce a grounded recommendation with alternatives.
5. **Validation loop:** check evidence integrity, run COV on synthesis, and record telemetry.
6. **Delivery:** provide recommendation, rationale, dissent, risks, and confidence ceiling.

### Output Format
- Question, constraints, and panel composition.
- Round summaries (proposals, critiques, evidence).
- Synthesis with chosen path, alternatives, and risk notes.
- **Confidence:** `X.XX (ceiling: TYPE Y.YY) - rationale`.

### Validation Checklist
- Structure-first assets present or planned; examples/tests updated or ticketed.
- Roles/timeboxes enforced; evidence cited; registry-only agents used; hooks within budget.
- Adversarial and COV results captured with MCP tags; confidence ceiling declared; English-only output.

### Completion Definition
Council run is complete when a recommendation (or documented stalemate) is delivered with evidence, dissent captured, risks owned, and MCP log persisted.

Confidence: 0.70 (ceiling: inference 0.70) - Council orchestration rewritten with skill-forge scaffolding and prompt-architect constraint and confidence discipline.
